"""Idempotent DB schema creation for deploy hooks (Render 'release' command,
Heroku release phase, or manual `python init_db.py`). Safe to run on every
deploy — db.create_all() only creates tables that don't already exist."""
import os
from app import create_app
from app.extensions import db

app = create_app(os.environ.get("FLASK_ENV", "production"))

with app.app_context():
    db.create_all()
    print("Database schema is up to date.")
