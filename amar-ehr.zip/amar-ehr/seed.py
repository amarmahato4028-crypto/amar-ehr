"""
Seed demo data for Amar EHR: one admin, two doctors, three patients, plus
sample appointments/vitals so the dashboards aren't empty on first run.

Run with:  python seed.py
"""
import os
os.environ.setdefault("FLASK_ENV", "development")

from datetime import timedelta
from app import create_app
from app.extensions import db
from app.models.user import User
from app.models.patient import PatientProfile
from app.models.doctor import DoctorProfile
from app.models.appointment import Appointment
from app.models.vitals import VitalReading
from app.utils.anomaly import evaluate_vitals
from app.utils.timeutils import utcnow

app = create_app(os.environ.get("FLASK_ENV", "development"))


def make_user(email, name, role, password, phone=None):
    """Phone must be unique (it can be used to sign in), so every demo
    account gets its own number."""
    existing = User.query.filter_by(email=email).first()
    if existing:
        return existing
    u = User(email=email, full_name=name, role=role, phone=User.normalize_phone(phone))
    u.set_password(password)
    db.session.add(u)
    db.session.flush()
    return u


with app.app_context():
    db.create_all()

    admin = make_user("admin@amarehr.com", "Amar Admin", "admin", "AdminPass123", phone="+15550100")

    doc1 = make_user("dr.sharma@amarehr.com", "Anita Sharma", "doctor", "DoctorPass123", phone="+15550101")
    if not doc1.doctor_profile:
        db.session.add(DoctorProfile(user_id=doc1.id, specialization="Cardiology",
                                      license_number="MCI-10234", years_experience=12,
                                      bio="Cardiologist focused on preventive heart health."))

    doc2 = make_user("dr.khan@amarehr.com", "Imran Khan", "doctor", "DoctorPass123", phone="+15550102")
    if not doc2.doctor_profile:
        db.session.add(DoctorProfile(user_id=doc2.id, specialization="General Medicine",
                                      license_number="MCI-88213", years_experience=7,
                                      bio="General physician, family medicine."))

    db.session.commit()

    patients_data = [
        ("amit.patel@example.com", "Amit Patel", "O+", "+15550111"),
        ("priya.nair@example.com", "Priya Nair", "B+", "+15550112"),
        ("rahul.verma@example.com", "Rahul Verma", "A-", "+15550113"),
    ]
    patient_profiles = []
    for email, name, blood, phone in patients_data:
        u = make_user(email, name, "patient", "PatientPass123", phone=phone)
        if not u.patient_profile:
            pp = PatientProfile(user_id=u.id, blood_group=blood)
            db.session.add(pp)
            db.session.flush()
            patient_profiles.append(pp)
        else:
            patient_profiles.append(u.patient_profile)
    db.session.commit()

    doc1_profile = doc1.doctor_profile
    doc2_profile = doc2.doctor_profile

    now = utcnow()
    if Appointment.query.count() == 0:
        appts = [
            Appointment(patient_id=patient_profiles[0].id, doctor_id=doc1_profile.id,
                        scheduled_at=now + timedelta(days=2, hours=3), reason="Routine checkup",
                        status="scheduled"),
            Appointment(patient_id=patient_profiles[1].id, doctor_id=doc1_profile.id,
                        scheduled_at=now + timedelta(days=1, hours=1), reason="Follow-up BP",
                        status="scheduled"),
            Appointment(patient_id=patient_profiles[2].id, doctor_id=doc2_profile.id,
                        scheduled_at=now - timedelta(days=5), reason="Fever", status="completed"),
            Appointment(patient_id=patient_profiles[0].id, doctor_id=doc2_profile.id,
                        scheduled_at=now - timedelta(days=10), reason="General consultation",
                        status="completed"),
            # A spread of statuses so the doctor dashboard's breakdown chart
            # renders with more than one segment on first run.
            Appointment(patient_id=patient_profiles[1].id, doctor_id=doc1_profile.id,
                        scheduled_at=now - timedelta(days=3), reason="Follow-up",
                        status="cancelled"),
            Appointment(patient_id=patient_profiles[2].id, doctor_id=doc1_profile.id,
                        scheduled_at=now - timedelta(days=7), reason="Cardiac screening",
                        status="no_show"),
            Appointment(patient_id=patient_profiles[0].id, doctor_id=doc1_profile.id,
                        scheduled_at=now + timedelta(hours=3), reason="BP review",
                        status="scheduled"),
        ]
        db.session.add_all(appts)
        db.session.commit()

    if VitalReading.query.count() == 0:
        sample_vitals = [
            (patient_profiles[0], 118, 76, 72, 95, 36.6, 98, 70),
            (patient_profiles[0], 145, 92, 88, 110, 37.0, 97, 71),
            (patient_profiles[1], 150, 95, 90, 185, 38.2, 95, 65),
            (patient_profiles[2], 110, 70, 68, 88, 36.8, 99, 60),
        ]
        for p, sys_bp, dia_bp, hr, sugar, temp, spo2, weight in sample_vitals:
            v = VitalReading(patient_id=p.id, systolic_bp=sys_bp, diastolic_bp=dia_bp,
                              heart_rate=hr, blood_sugar=sugar, temperature=temp, spo2=spo2,
                              weight_kg=weight)
            flags, _ = evaluate_vitals(v)
            v.risk_flags = flags
            db.session.add(v)
        db.session.commit()

    print("Seed complete.")
    print("Admin login:  admin@amarehr.com / AdminPass123 (2FA setup required on first login)")
    print("Doctor login: dr.sharma@amarehr.com / DoctorPass123 (2FA setup required on first login)")
    print("Doctor login: dr.khan@amarehr.com / DoctorPass123 (2FA setup required on first login)")
    print("Patient login: amit.patel@example.com / PatientPass123")
    print("   (or sign in with the mobile number +15550111 and the same password)")
    print("Patient login: priya.nair@example.com / PatientPass123")
    print("Patient login: rahul.verma@example.com / PatientPass123")
