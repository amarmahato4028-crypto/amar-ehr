"""
Render every Jinja template with realistic stand-in data and stitch the
results into a single browsable preview file.

Two jobs:
  1. Shows what the running app actually looks like, without needing the
     Flask stack installed.
  2. Doubles as a smoke test — rendering (not just parsing) catches
     undefined variables, bad attribute access and broken filters that a
     syntax check misses.

Not part of the app; lives in tools/ so it never ships in a request path.
"""
import os
import sys
import html
import random
from datetime import datetime, timedelta
from types import SimpleNamespace

import jinja2
from markupsafe import Markup

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATES = os.path.join(ROOT, "app", "templates")

NOW = datetime(2026, 8, 15, 10, 30)


# ---------------------------------------------------------------- fake forms
class F:
    """Stand-in for a WTForms field: renders the same markup the real one
    would, so the preview reflects true layout."""

    def __init__(self, label, kind="text", value="", choices=None, errors=None,
                 description=""):
        self._label = label
        self.kind = kind
        self.data = value
        self.choices = choices or []
        self.errors = errors or []
        self.description = description

    def label(self, **kw):
        cls = kw.get("class", "")
        return Markup(f'<label class="{cls}">{html.escape(self._label)}</label>')

    def __call__(self, **kw):
        # Pass through the attributes real WTForms would render (id,
        # autocomplete, inputmode, maxlength...) — the prototype's scripts
        # look elements up by id, so dropping them breaks the page.
        cls = kw.pop("class", "")
        ph = kw.pop("placeholder", "")
        rows = kw.pop("rows", None)
        kw.pop("type", None)
        extra = " ".join(
            f'{k.replace("_", "-")}="{html.escape(str(v), quote=True)}"'
            for k, v in kw.items() if v not in (None, False))
        val = html.escape(str(self.data if self.data is not None else ""), quote=True)

        if self.kind == "select":
            opts = "".join(
                f'<option {"selected" if str(v) == str(self.data) else ""}>{html.escape(str(t))}</option>'
                for v, t in self.choices)
            return Markup(f'<select class="{cls}" {extra}>{opts}</select>')
        if self.kind == "textarea":
            return Markup(f'<textarea class="{cls}" rows="{rows or 3}" '
                          f'placeholder="{html.escape(ph, quote=True)}" {extra}>{val}</textarea>')
        if self.kind == "submit":
            return Markup(f'<button type="submit" class="{cls}" {extra}>'
                          f'{html.escape(self._label)}</button>')
        if self.kind == "checkbox":
            return Markup(f'<input type="checkbox" class="{cls}" checked {extra}>')
        return Markup(f'<input type="{self.kind}" class="{cls}" value="{val}" '
                      f'placeholder="{html.escape(ph, quote=True)}" {extra}>')


class Form:
    def __init__(self, **fields):
        self.__dict__.update(fields)
        self._fields = fields

    def hidden_tag(self):
        return Markup('<input type="hidden" value="csrf-token-preview">')


# ------------------------------------------------------------- fake QR image
def fake_qr_data_uri(seed=7, n=25):
    """A deterministic QR-looking SVG. The real app uses the `qrcode`
    library; this is only so the preview isn't an empty box."""
    rnd = random.Random(seed)
    cells = []
    for y in range(n):
        for x in range(n):
            corner = (x < 8 and y < 8) or (x >= n - 8 and y < 8) or (x < 8 and y >= n - 8)
            if corner:
                continue
            if rnd.random() < 0.45:
                cells.append(f'<rect x="{x}" y="{y}" width="1" height="1"/>')

    def finder(ox, oy):
        return (f'<rect x="{ox}" y="{oy}" width="7" height="7" fill="none" stroke="#000" stroke-width="1"/>'
                f'<rect x="{ox+2}" y="{oy+2}" width="3" height="3"/>')

    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {n} {n}" '
           f'shape-rendering="crispEdges"><rect width="{n}" height="{n}" fill="#fff"/>'
           f'<g fill="#000">{"".join(cells)}{finder(0,0)}{finder(n-7,0)}{finder(0,n-7)}</g></svg>')
    import base64
    return "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode()


QR = fake_qr_data_uri()


# ------------------------------------------------------------------ fake data
def user(name, email, role, twofa=False, active=True, locked=False):
    u = SimpleNamespace(full_name=name, email=email, role=role, id=abs(hash(email)) % 900 + 1,
                        two_fa_enabled=twofa, is_active_account=active,
                        is_authenticated=True, phone="+1 555 0142")
    u.is_locked = lambda: locked
    return u


PATIENT_U = user("Amit Patel", "amit.patel@example.com", "patient")
DOC1_U = user("Anita Sharma", "dr.sharma@amarehr.com", "doctor", twofa=True)
DOC2_U = user("Imran Khan", "dr.khan@amarehr.com", "doctor", twofa=True)
ADMIN_U = user("Amar Admin", "admin@amarehr.com", "admin", twofa=True)

DOC1 = SimpleNamespace(id=1, user=DOC1_U, specialization="Cardiology",
                       years_experience=12, license_number="MCI-10234",
                       bio="Cardiologist focused on preventive heart health.")
DOC2 = SimpleNamespace(id=2, user=DOC2_U, specialization="General Medicine",
                       years_experience=7, license_number="MCI-88213",
                       bio="General physician, family medicine.")
DOC3 = SimpleNamespace(id=3, user=user("Sara Iyer", "dr.iyer@amarehr.com", "doctor", twofa=True),
                       specialization="Dermatology", years_experience=5,
                       license_number="MCI-55190", bio="Skin, hair and nail conditions.")

PATIENT = SimpleNamespace(id=1, user=PATIENT_U, public_uid="7f3a9c21-4b8e-4d12-9a6f-2c5e8b1d0a44",
                          blood_group="O+", known_allergies="Penicillin",
                          chronic_conditions="Hypertension (stage 1)",
                          date_of_birth="1998-04-12", gender="male",
                          address="14 Rosewood Lane, Springfield",
                          emergency_contact="Meera Patel — +1 555 0188")
PATIENT_U.patient_profile = PATIENT
DOC1_U.doctor_profile = DOC1

PATIENTS = [
    PATIENT,
    SimpleNamespace(id=2, user=user("Priya Nair", "priya.nair@example.com", "patient"),
                    blood_group="B+", known_allergies="—", chronic_conditions="Type 2 diabetes"),
    SimpleNamespace(id=3, user=user("Rahul Verma", "rahul.verma@example.com", "patient"),
                    blood_group="A-", known_allergies="Sulfa drugs", chronic_conditions="—"),
]


def appt(i, p, d, when, status="scheduled", reason="Routine checkup"):
    return SimpleNamespace(id=i, patient=p, doctor=d, patient_id=p.id, doctor_id=d.id,
                           scheduled_at=when, status=status, reason=reason)


UPCOMING_P = [
    appt(1, PATIENT, DOC1, NOW + timedelta(hours=3), reason="BP review"),
    appt(2, PATIENT, DOC2, NOW + timedelta(days=2, hours=1), reason="Annual checkup"),
]
ALL_APPTS_P = UPCOMING_P + [
    appt(3, PATIENT, DOC2, NOW - timedelta(days=10), "completed", "General consultation"),
    appt(4, PATIENT, DOC1, NOW - timedelta(days=25), "cancelled", "Follow-up"),
]
UPCOMING_D = [
    appt(1, PATIENTS[0], DOC1, NOW + timedelta(hours=3), reason="BP review"),
    appt(5, PATIENTS[1], DOC1, NOW + timedelta(days=1, hours=2), reason="Follow-up BP"),
    appt(6, PATIENTS[2], DOC1, NOW + timedelta(days=4), reason="Cardiac screening"),
]
ALL_APPTS_D = UPCOMING_D + [
    appt(7, PATIENTS[1], DOC1, NOW - timedelta(days=3), "cancelled", "Follow-up"),
    appt(8, PATIENTS[2], DOC1, NOW - timedelta(days=7), "no_show", "Cardiac screening"),
    appt(9, PATIENTS[0], DOC1, NOW - timedelta(days=12), "completed", "Initial consult"),
]


def rx(i, med, dose, freq):
    return SimpleNamespace(id=i, medication=med, dosage=dose, frequency=freq,
                           duration="30 days", instructions="Take after food.",
                           created_at=NOW - timedelta(days=5))


RECORDS = [
    SimpleNamespace(id=1, record_type="diagnosis", created_at=NOW - timedelta(days=5),
                    doctor=DOC1, patient_id=1,
                    diagnosis="Hypertension, stage 1",
                    notes="Patient reports intermittent headaches. Advised low-sodium diet, "
                          "daily BP logging and review in 4 weeks.",
                    prescriptions=[rx(1, "Amlodipine", "5 mg", "Once daily")]),
    SimpleNamespace(id=2, record_type="consultation", created_at=NOW - timedelta(days=25),
                    doctor=DOC2, patient_id=1,
                    diagnosis="Viral upper respiratory infection",
                    notes="Symptomatic management. Fluids and rest advised.",
                    prescriptions=[rx(2, "Paracetamol", "500 mg", "Every 6 hours as needed")]),
]


def vital(i, days_ago, sys, dia, hr, sugar, temp, spo2, flags=""):
    return SimpleNamespace(id=i, recorded_at=NOW - timedelta(days=days_ago),
                           systolic_bp=sys, diastolic_bp=dia, heart_rate=hr,
                           blood_sugar=sugar, temperature=temp, spo2=spo2,
                           weight_kg=71, risk_flags=flags)


VITALS = [
    vital(1, 0, 145, 92, 88, 110, 37.0, 97, "HIGH_BP"),
    vital(2, 3, 138, 88, 76, 102, 36.8, 98),
    vital(3, 7, 142, 90, 80, 98, 36.7, 98, "HIGH_BP"),
    vital(4, 14, 128, 82, 72, 95, 36.6, 99),
    vital(5, 21, 118, 76, 70, 92, 36.5, 99),
]


def logentry(i, u, action, tt, ti, details="", mins=0):
    return SimpleNamespace(id=i, user=u, action=action, target_type=tt, target_id=ti,
                           details=details, ip_address="10.0.0.%d" % (20 + i % 5),
                           timestamp=NOW - timedelta(minutes=mins))


LOGS = [
    logentry(412, DOC1_U, "VIEW_PATIENT_RECORD", "patient_profile", 1, mins=2),
    logentry(411, DOC1_U, "CREATE_PRESCRIPTION", "prescription", 1, mins=5),
    logentry(410, DOC1_U, "CREATE_RECORD", "medical_record", 1, mins=6),
    logentry(409, PATIENT_U, "EXPORT_PDF", "patient_profile", 1, "encrypted records export", mins=14),
    logentry(408, PATIENT_U, "LOG_VITALS", "vital_reading", 1, "HIGH_BP", mins=20),
    logentry(407, PATIENT_U, "LOGIN_SUCCESS", "user", 1, mins=22),
    logentry(406, None, "LOGIN_FAILED", "user", 1, mins=23),
    logentry(405, ADMIN_U, "VERIFY_AUDIT_CHAIN", "admin", None, "valid=True", mins=40),
    logentry(404, ADMIN_U, "TOGGLE_USER_ACTIVE", "user", 5, "active=False", mins=45),
    logentry(403, DOC1_U, "ACCESS_DENIED", "patient.records", None, "role=doctor", mins=51),
]

LAB_REPORTS = [
    SimpleNamespace(id=1, title="Lipid Panel", original_filename="lipid_panel_aug.pdf",
                    uploaded_at=NOW - timedelta(days=4)),
    SimpleNamespace(id=2, title="Chest X-Ray", original_filename="chest_xray.png",
                    uploaded_at=NOW - timedelta(days=18)),
]

PAGINATION = SimpleNamespace(items=LOGS, page=1, pages=11, has_prev=False, has_next=True,
                             prev_num=0, next_num=2)


# --------------------------------------------------------------- jinja set-up
def build_env():
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(TEMPLATES),
                             autoescape=True, undefined=jinja2.StrictUndefined)

    def localdt(dt, fmt="%a, %d %b · %I:%M %p"):
        if dt is None:
            return "-"
        if isinstance(dt, str):
            return dt
        return Markup(f'<time>{dt.strftime(fmt)}</time>')

    env.filters["localdt"] = localdt

    # Plain-language filters, imported from the real module so the preview
    # can't drift from what the app actually renders.
    # Load by file path: importing app.utils.display would pull in the
    # whole Flask app package, which isn't installable in every sandbox.
    import importlib.util as _ilu
    _spec = _ilu.spec_from_file_location(
        "_display", os.path.join(ROOT, "app", "utils", "display.py"))
    _d = _ilu.module_from_spec(_spec)
    _spec.loader.exec_module(_d)
    env.filters.update(
        risk_labels=_d.risk_labels, risk_text=_d.risk_label_text,
        risk_severity=_d.worst_severity, status_label=_d.status_label,
        status_colour=_d.status_colour, action_label=_d.action_label,
        role_label=_d.role_label, detail_text=_d.detail_text,
    )
    env.globals["nav_active"] = lambda *eps: ""  # replaced per-page in main()

    def url_for(endpoint, **kw):
        # Inline real assets so the prototype behaves like the app: the
        # stylesheet, and the JS that drives tabs, toggles and the chat.
        if endpoint == "static":
            fn = kw.get("filename", "")
            path = os.path.join(ROOT, "app", "static", fn)
            if not os.path.exists(path):
                return "#"
            import base64
            raw = open(path, "rb").read()
            mime = "text/css" if fn.endswith(".css") else "text/javascript"
            return f"data:{mime};base64," + base64.b64encode(raw).decode()
        # Everything else becomes a navigation target the shell understands.
        return "#!" + endpoint

    env.globals.update(
        url_for=url_for,
        csrf_token=lambda: "csrf-token-preview",
        get_flashed_messages=lambda **kw: [],
    )
    return env


# Chart.js loads from its real CDN inside the preview, but the app's own
# init scripts are stubbed out — so supply equivalent inline data here to
# show what the dashboards actually look like populated.
CHART_SCRIPTS = {
    "patient/dashboard.html": """
<script>
new Chart(document.getElementById('vitalsChart'), {
  type: 'line',
  data: {
    labels: ['07-25','08-01','08-08','08-12','08-15'],
    datasets: [
      {label:'Systolic BP', data:[118,128,142,138,145], borderColor:'#0f766e', tension:.3},
      {label:'Diastolic BP', data:[76,82,90,88,92], borderColor:'#1d4ed8', tension:.3},
      {label:'Heart Rate', data:[70,72,80,76,88], borderColor:'#b45309', tension:.3}
    ]
  },
  options: {responsive:true, plugins:{legend:{position:'bottom'}}}
});
</script>""",
    "doctor/dashboard.html": """
<script>
new Chart(document.getElementById('statsChart'), {
  type: 'doughnut',
  data: {labels:['scheduled','completed','cancelled','no_show'],
         datasets:[{data:[3,1,1,1], backgroundColor:['#0f766e','#1d4ed8','#b45309','#64748b']}]},
  options: {plugins:{legend:{position:'bottom'}}}
});
</script>""",
}


VITALS_FORM = dict(
    systolic_bp=F("Systolic BP"), diastolic_bp=F("Diastolic BP"),
    heart_rate=F("Heart Rate (bpm)"), blood_sugar=F("Blood Sugar (mg/dL)"),
    temperature=F("Temperature (°C)"), spo2=F("SpO2 (%)"), weight_kg=F("Weight (kg)"),
    submit=F("Record Vitals", "submit"))

_hc_spec = __import__("importlib.util", fromlist=["util"]).spec_from_file_location(
    "_hc", os.path.join(ROOT, "app", "utils", "health_check.py"))
_hc = __import__("importlib.util", fromlist=["util"]).module_from_spec(_hc_spec)
_hc_spec.loader.exec_module(_hc)


class _Reading:
    def __init__(self, **kw):
        for f in ("systolic_bp", "diastolic_bp", "heart_rate", "blood_sugar",
                  "temperature", "spo2", "weight_kg"):
            setattr(self, f, kw.get(f))


# A deliberately mixed reading so the preview shows good, watch and
# needs-attention side by side.
_HC_READING = _Reading(systolic_bp=145, diastolic_bp=92, heart_rate=88,
                       spo2=97, blood_sugar=110, temperature=36.8, weight_kg=78)
HC_RESULTS = _hc.assess_reading(_HC_READING, height_cm=170)
HC_SUMMARY = _hc.overall(HC_RESULTS)

SELF_CHECK_FORM = Form(
    systolic_bp=F("Blood pressure — top number", value=145, description="e.g. 120"),
    diastolic_bp=F("Blood pressure — bottom number", value=92, description="e.g. 80"),
    heart_rate=F("Heart rate", value=88, description="Beats per minute, e.g. 72"),
    spo2=F("Oxygen level", value=97, description="From a fingertip oximeter, e.g. 98"),
    blood_sugar=F("Blood sugar", value=110, description="From a glucose meter, in mg/dL, e.g. 95"),
    temperature=F("Body temperature", value=36.8, description="In °C, e.g. 36.6"),
    weight_kg=F("Weight", value=78, description="In kilograms — needed for BMI"),
    height_cm=F("Height", value=170, description="In centimetres — needed for BMI"),
    save_reading=F("Also save this to my records", "checkbox"),
    submit=F("Check my readings", "submit"))

PAGES = [
    ("Sign in / Create account", "auth/entry.html", dict(
        active_tab="login",
        login_form=Form(
            identifier=F("Email or mobile number", value="",
                         description="Whichever you signed up with"),
            password=F("Password", "password"),
            totp_code=F("6-digit code"),
            submit=F("Sign in", "submit")),
        register_form=Form(
            full_name=F("Your full name"), email=F("Email address"),
            phone=F("Mobile number"),
            role=F("I am a", "select", "Patient",
                   [("patient", "Patient"), ("doctor", "Doctor")]),
            password=F("Create a password", "password",
                       description="At least 8 characters, with a letter and a number"),
            confirm_password=F("Type your password again", "password"),
            submit=F("Create my account", "submit")))),
    ("Sign in — Create account tab", "auth/entry.html", dict(
        active_tab="register",
        login_form=Form(
            identifier=F("Email or mobile number", description="Whichever you signed up with"),
            password=F("Password", "password"), totp_code=F("6-digit code"),
            submit=F("Sign in", "submit")),
        register_form=Form(
            full_name=F("Your full name"), email=F("Email address"),
            phone=F("Mobile number"),
            role=F("I am a", "select", "Patient",
                   [("patient", "Patient"), ("doctor", "Doctor")]),
            password=F("Create a password", "password",
                       description="At least 8 characters, with a letter and a number"),
            confirm_password=F("Type your password again", "password"),
            submit=F("Create my account", "submit")))),
    ("2FA setup (doctors & admins)", "auth/setup_2fa.html", dict(
        current_user=DOC1_U, qr_data_uri=QR, secret="JBSWY3DPEHPK3PXP",
        form=Form(totp_code=F("Enter code from authenticator app"),
                  submit=F("Verify & Enable 2FA", "submit")))),
    ("Patient — dashboard", "patient/dashboard.html", dict(
        current_user=PATIENT_U, profile=PATIENT, upcoming=UPCOMING_P,
        recent_vitals=VITALS, active_flags=[v for v in VITALS if v.risk_flags])),
    ("Patient — health check", "patient/health_check.html", dict(
        current_user=PATIENT_U, form=SELF_CHECK_FORM, results=HC_RESULTS,
        summary=HC_SUMMARY, saved=False, height_cm=170, has_reading=True)),
    ("Patient — my records", "patient/records.html", dict(
        current_user=PATIENT_U, records=RECORDS, search="")),
    ("Patient — appointments", "patient/appointments.html", dict(
        current_user=PATIENT_U, appointments=ALL_APPTS_P)),
    ("Patient — find a doctor", "patient/doctors.html", dict(
        current_user=PATIENT_U, doctors=[DOC1, DOC3, DOC2],
        specializations=["Cardiology", "Dermatology", "General Medicine"], current_spec="")),
    ("Patient — book appointment", "patient/book_appointment.html", dict(
        current_user=PATIENT_U,
        form=Form(doctor_id=F("Doctor", "select", "Dr. Anita Sharma — Cardiology",
                              [(1, "Dr. Anita Sharma — Cardiology"), (2, "Dr. Imran Khan — General Medicine")]),
                  scheduled_at=F("Date & Time"), reason=F("Reason for visit"),
                  submit=F("Book Appointment", "submit")))),
    ("Patient — log vitals", "patient/log_vitals.html", dict(
        current_user=PATIENT_U, form=Form(**{**VITALS_FORM, "submit": F("Log Vitals", "submit")}))),
    ("Patient — my details", "patient/profile.html", dict(
        current_user=PATIENT_U, profile=PATIENT,
        form=Form(date_of_birth=F("Date of birth", "date", "1998-04-12"),
                  gender=F("Gender", "select", "Male",
                           [("", "Prefer not to say"), ("female", "Female"), ("male", "Male")]),
                  blood_group=F("Blood group", "select", "O+",
                                [("", "I don't know"), ("O+", "O+"), ("A+", "A+")],
                                description="Shown on your health card"),
                  height_cm=F("Height", value=170,
                              description="In centimetres — we use this to work out your BMI"),
                  address=F("Home address", "textarea", "14 Rosewood Lane, Springfield"),
                  emergency_contact=F("Emergency contact", value="Meera Patel — +1 555 0188",
                                      description="Name and phone number of someone we can call"),
                  known_allergies=F("Allergies", "textarea", "Penicillin",
                                    description="Medicines or foods you react badly to."),
                  chronic_conditions=F("Ongoing conditions", "textarea", "Hypertension (stage 1)",
                                       description="Anything you're managing long-term"),
                  submit=F("Save my details", "submit")))),
    ("Doctor — my details", "doctor/profile.html", dict(
        current_user=DOC1_U, profile=DOC1,
        form=Form(specialization=F("Specialization", value="Cardiology"),
                  license_number=F("License Number", value="MCI-10234"),
                  years_experience=F("Years of Experience", value=12),
                  bio=F("Bio", "textarea", "Cardiologist focused on preventive heart health."),
                  submit=F("Save Profile", "submit")))),
    ("Doctor — record vitals", "doctor/add_vitals.html", dict(
        current_user=DOC1_U, patient=PATIENT,
        form=Form(systolic_bp=F("Systolic BP", description="mmHg"),
                  diastolic_bp=F("Diastolic BP", description="mmHg"),
                  heart_rate=F("Heart rate", description="bpm"),
                  spo2=F("SpO\u2082", description="%"),
                  blood_sugar=F("Blood glucose", description="mg/dL"),
                  temperature=F("Temperature", description="\u00b0C"),
                  weight_kg=F("Weight", description="kg"),
                  submit=F("Record vitals", "submit")))),
    ("Patient — QR health card", "patient/health_card.html", dict(
        current_user=PATIENT_U, profile=PATIENT, qr_data_uri=QR)),
    ("Patient — encrypted PDF export", "patient/export_records.html", dict(
        current_user=PATIENT_U,
        form=Form(password=F("Set a password to protect your PDF export", "password"),
                  submit=F("Generate Encrypted PDF", "submit")))),
    ("Doctor — dashboard", "doctor/dashboard.html", dict(
        current_user=DOC1_U, profile=DOC1, upcoming=UPCOMING_D, patient_count=3,
        status_counts={"scheduled": 3, "completed": 1, "cancelled": 1, "no_show": 1})),
    ("Doctor — my patients", "doctor/patients.html", dict(
        current_user=DOC1_U, patients=PATIENTS)),
    ("Doctor — patient detail", "doctor/patient_detail.html", dict(
        current_user=DOC1_U, patient=PATIENT, records=RECORDS, vitals=VITALS)),
    ("Doctor — appointments & status", "doctor/appointments.html", dict(
        current_user=DOC1_U, appointments=ALL_APPTS_D, status_filter="")),
    ("Doctor — new record", "doctor/add_record.html", dict(
        current_user=DOC1_U, patient=PATIENT,
        form=Form(record_type=F("Type", "select", "Diagnosis",
                                [("consultation", "Consultation"), ("diagnosis", "Diagnosis"), ("note", "Note")]),
                  diagnosis=F("Diagnosis", "textarea"), notes=F("Clinical Notes", "textarea"),
                  submit=F("Save Record", "submit")))),
    ("Doctor — new prescription", "doctor/add_prescription.html", dict(
        current_user=DOC1_U, record=SimpleNamespace(patient=PATIENT),
        form=Form(medication=F("Medication"), dosage=F("Dosage"), frequency=F("Frequency"),
                  duration=F("Duration"), instructions=F("Instructions", "textarea"),
                  submit=F("Generate Prescription", "submit")))),
    ("Admin — dashboard", "admin/dashboard.html", dict(
        current_user=ADMIN_U, total_users=6, total_patients=3, total_doctors=2,
        recent_logs=LOGS)),
    ("Admin — user management", "admin/users.html", dict(
        current_user=ADMIN_U,
        users=[ADMIN_U, DOC1_U, DOC2_U, PATIENT_U,
               user("Priya Nair", "priya.nair@example.com", "patient"),
               user("Rahul Verma", "rahul.verma@example.com", "patient", active=False, locked=True)])),
    ("Admin — audit trail", "admin/audit_trail.html", dict(
        current_user=ADMIN_U, pagination=PAGINATION, user_q="", action_q="",
        actions=["ACCESS_DENIED", "BOOK_APPOINTMENT", "CREATE_RECORD", "EXPORT_PDF",
                 "LOGIN_FAILED", "LOGIN_SUCCESS", "LOG_VITALS", "VIEW_PATIENT_RECORD"])),
    ("Admin — chain integrity check", "admin/verify_chain.html", dict(
        current_user=ADMIN_U, is_valid=True, broken_id=None, total_entries=412)),
    ("Admin — chain integrity: TAMPERED", "admin/verify_chain.html", dict(
        current_user=ADMIN_U, is_valid=False, broken_id=207, total_entries=412)),
    ("Lab reports & scans", "records/lab_reports.html", dict(
        current_user=PATIENT_U, reports=LAB_REPORTS, patient=PATIENT)),
    ("Upload lab report", "records/upload_lab_report.html", dict(
        current_user=PATIENT_U, patient=PATIENT,
        form=Form(title=F("Report Title"), file=F("File (PDF/JPG/PNG)", "file"),
                  submit=F("Upload", "submit")))),
    ("Record search", "records/search_results.html", dict(
        current_user=DOC1_U, results=RECORDS, q="hypertension")),
    ("Error — 403 forbidden", "errors/403.html", dict(current_user=PATIENT_U)),
    ("Error — 413 file too large", "errors/413.html", dict(current_user=PATIENT_U, max_mb=10)),
]


# Maps each rendered screen to the Flask endpoint it represents, so links
# inside the prototype can find their destination. Duplicate templates are
# disambiguated by the screen title.
ENDPOINT_BY_TITLE = {
    "Sign in / Create account": "auth.login",
    "Sign in — Create account tab": "auth.register",
    "Admin — chain integrity: TAMPERED": "__tampered__",
}


def endpoint_for(title, tpl):
    if title in ENDPOINT_BY_TITLE:
        return ENDPOINT_BY_TITLE[title]
    base = tpl[:-5]                                  # drop .html
    special = {
        "admin/verify_chain": "admin.verify_audit_chain",
        "records/lab_reports": "records.lab_reports_for_patient",
        "records/search_results": "records.search",
        "records/upload_lab_report": "records.upload_lab_report",
        "auth/setup_2fa": "auth.setup_2fa",
    }
    if base in special:
        return special[base]
    if base.startswith("errors/"):
        return "__error_" + base.split("/")[1]
    return base.replace("/", ".")


# Injected into every screen: turns the app's own links and buttons into
# prototype navigation, and fakes the one network call the chat widget makes.
BRIDGE_JS = """
<script>
(function () {
  function go(ep) { parent.postMessage({ amarNav: ep }, '*'); }

  document.addEventListener('click', function (e) {
    var a = e.target.closest('a[href^="#!"]');
    if (!a) return;
    e.preventDefault();
    go(a.getAttribute('href').slice(2));
  });

  document.addEventListener('submit', function (e) {
    var form = e.target;
    e.preventDefault();
    var action = form.getAttribute('action') || '';

    if (action.indexOf('auth.login') !== -1) {
      // Route to whichever dashboard the typed account belongs to.
      var id = (form.querySelector('#login-email') || {}).value || '';
      id = id.toLowerCase();
      if (id.indexOf('admin') !== -1) return go('admin.dashboard');
      if (id.indexOf('dr.') === 0 || id.indexOf('dr.') !== -1) return go('doctor.dashboard');
      if (!id.trim()) return toast('Enter an account, or tap “Use the demo account”.');
      return go('patient.dashboard');
    }
    if (action.indexOf('auth.register') !== -1) return go('auth.login');
    if (action.indexOf('auth.logout') !== -1) return go('auth.login');
    toast('This is a preview — in the running app, this saves to the database.');
  });

  function toast(msg) {
    var t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = 'position:fixed;left:50%;bottom:26px;transform:translateX(-50%);' +
      'background:#0f172a;color:#fff;padding:.7rem 1.1rem;border-radius:10px;font-size:.85rem;' +
      'z-index:9999;box-shadow:0 8px 24px rgba(0,0,0,.25);max-width:90%;text-align:center;';
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2600);
  }

  // The chat widget posts to /api/chatbot; answer it locally instead.
  var realFetch = window.fetch;
  window.fetch = function (url, opts) {
    if (String(url).indexOf('/api/chatbot') !== -1) {
      var msg = '';
      try { msg = JSON.parse(opts.body).message.toLowerCase(); } catch (err) {}
      var reply = "I can help with common symptoms — fever, headache, cough, blood " +
                  "pressure, blood sugar — or with booking an appointment. Could you " +
                  "describe your symptom in a bit more detail?";
      if (/chest pain|can't breathe|cannot breathe/.test(msg))
        reply = "This may be a medical emergency. Please call your local emergency " +
                "number or go to the nearest emergency room immediately.";
      else if (/fever|temperature|chills/.test(msg))
        reply = "A fever can indicate infection. Stay hydrated, rest, and monitor your " +
                "temperature. If it stays above 39\u00b0C for more than 2 days, book an appointment.";
      else if (/headache|migraine/.test(msg))
        reply = "For headaches: rest in a dark quiet room, stay hydrated, and consider an " +
                "over-the-counter pain reliever if you have no contraindications.";
      else if (/blood pressure|\bbp\b/.test(msg))
        reply = "High blood pressure is often symptomless — regular monitoring matters. " +
                "Log your readings so trends are visible to your doctor.";
      else if (/appointment|book|schedule/.test(msg))
        reply = "You can book from your dashboard under “Book an appointment”.";
      return Promise.resolve({ json: function () { return Promise.resolve({ reply: reply }); } });
    }
    return realFetch.apply(this, arguments);
  };
})();
</script>
"""


def main():
    env = build_env()
    rendered, failures = [], []

    for title, tpl, ctx in PAGES:
        try:
            current_ep = endpoint_for(title, tpl)
            env.globals["nav_active"] = (
                lambda *eps, _cur=current_ep: "active" if _cur in eps else "")
            doc = env.get_template(tpl).render(**ctx)
            if tpl in CHART_SCRIPTS:
                doc = doc.replace("</body>", CHART_SCRIPTS[tpl] + "\n</body>")
            doc = doc.replace("</body>", BRIDGE_JS + "\n</body>")
            rendered.append((title, current_ep, doc))
        except Exception as e:
            failures.append((title, tpl, f"{type(e).__name__}: {e}"))

    for title, tpl, err in failures:
        print(f"  RENDER FAIL  {tpl:42} {err}", file=sys.stderr)
    print(f"\nRendered {len(rendered)}/{len(PAGES)} screens; {len(failures)} failed.")

    frames = "".join(
        f'<iframe class="screen" data-ep="{html.escape(ep, quote=True)}" '
        f'data-title="{html.escape(t, quote=True)}" '
        f'srcdoc="{html.escape(doc, quote=True)}"></iframe>'
        for t, ep, doc in rendered)

    index = {ep: i for i, (_, ep, _) in enumerate(rendered)}

    shell = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Amar EHR</title>
<style>
  html, body {{ margin:0; height:100%; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; background:#f2f7f8; }}
  .screen {{ display:none; width:100%; height:100%; border:0; }}
  .screen.active {{ display:block; }}
  #chrome {{
    position:fixed; right:16px; bottom:16px; z-index:99;
    display:flex; gap:8px; align-items:center;
    background:rgba(15,23,42,.9); color:#fff; padding:.45rem .5rem .45rem .85rem;
    border-radius:999px; font-size:.76rem; box-shadow:0 8px 24px rgba(0,0,0,.22);
    backdrop-filter:blur(6px);
  }}
  #chrome button {{
    font:inherit; font-size:.74rem; border:0; border-radius:999px; cursor:pointer;
    padding:.32rem .7rem; background:rgba(255,255,255,.16); color:#fff;
  }}
  #chrome button:hover {{ background:rgba(255,255,255,.28); }}
  #chrome .dot {{ width:7px; height:7px; border-radius:50%; background:#22c55e; }}
</style></head><body>

{frames}

<div id="chrome">
  <span class="dot"></span>
  <span>Interactive preview</span>
  <button id="btn-restart" title="Back to the sign-in screen">Restart</button>
</div>

<script>
  var INDEX = {index!r};
  var screens = document.querySelectorAll('.screen');

  // Nav links the app doesn't have a screen for fall back to something sensible.
  var FALLBACK = {{
    'main.index': 'auth.login',
    'main.dashboard': 'patient.dashboard',
    'auth.logout': 'auth.login',
    'auth.disable_2fa': 'patient.profile',
    'patient.cancel_appointment': 'patient.appointments',
    'patient.vitals_chart_data': 'patient.dashboard',
    'doctor.appointment_stats_data': 'doctor.dashboard',
    'doctor.update_appointment_status': 'doctor.appointments',
    'admin.toggle_active': 'admin.users',
    'admin.unlock_user': 'admin.users',
    'records.download_prescription': 'patient.records',
    'records.download_lab_report': 'records.lab_reports_for_patient'
  }};

  function show(ep) {{
    if (!(ep in INDEX) && FALLBACK[ep]) ep = FALLBACK[ep];
    if (!(ep in INDEX)) return;
    var i = INDEX[ep];
    screens.forEach(function (s, n) {{ s.classList.toggle('active', n === i); }});
    try {{ history.replaceState(null, '', '#' + ep); }} catch (e) {{}}
    window.scrollTo(0, 0);
  }}

  window.addEventListener('message', function (e) {{
    if (e.data && e.data.amarNav) show(e.data.amarNav);
  }});

  document.getElementById('btn-restart').addEventListener('click', function () {{
    show('auth.login');
  }});

  var start = (location.hash || '').replace('#', '');
  show(start && start in INDEX ? start : 'auth.login');
</script>
</body></html>"""

    out = os.path.join(ROOT, "amar_ehr_preview.html")
    with open(out, "w") as f:
        f.write(shell)
    print(f"Wrote {out}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
