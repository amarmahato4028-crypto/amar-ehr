import os
from app import create_app
from app.scheduler import start_scheduler

app = create_app(os.environ.get("FLASK_ENV", "production"))

# Only start the background reminder scheduler in the main process (avoids
# duplicate jobs under Flask's debug reloader).
if os.environ.get("WERKZEUG_RUN_MAIN") != "true" or not app.debug:
    start_scheduler(app)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=(os.environ.get("FLASK_ENV") == "development"))
