"""Anomaly rules, the chatbot, and the PDF/QR document pipeline."""
import pytest

from app.utils.anomaly import evaluate_vitals
from app.utils.chatbot import get_response
from app.models.vitals import VitalReading


class _V:
    """Lightweight stand-in for a VitalReading."""
    def __init__(self, **kw):
        for f in ("systolic_bp", "diastolic_bp", "heart_rate", "blood_sugar",
                  "temperature", "spo2", "weight_kg"):
            setattr(self, f, kw.get(f))


class TestAnomalyRules:
    def test_normal_vitals_produce_no_flags(self):
        flags, triggered = evaluate_vitals(
            _V(systolic_bp=118, diastolic_bp=76, heart_rate=72, blood_sugar=95,
               temperature=36.6, spo2=98))
        assert flags == ""
        assert triggered == []

    @pytest.mark.parametrize("kwargs,expected", [
        ({"systolic_bp": 150, "diastolic_bp": 95}, "HIGH_BP"),
        ({"systolic_bp": 85, "diastolic_bp": 55}, "LOW_BP"),
        ({"blood_sugar": 200}, "HIGH_SUGAR"),
        ({"blood_sugar": 60}, "LOW_SUGAR"),
        ({"heart_rate": 120}, "HIGH_HEART_RATE"),
        ({"heart_rate": 48}, "LOW_HEART_RATE"),
        ({"spo2": 88}, "LOW_SPO2"),
        ({"temperature": 39.0}, "FEVER"),
    ])
    def test_each_rule_fires(self, kwargs, expected):
        flags, _ = evaluate_vitals(_V(**kwargs))
        assert expected in flags

    def test_boundary_values_are_inclusive(self):
        # 140/90 is the hypertension threshold and should flag.
        assert "HIGH_BP" in evaluate_vitals(_V(systolic_bp=140, diastolic_bp=85))[0]
        assert "HIGH_BP" not in evaluate_vitals(_V(systolic_bp=139, diastolic_bp=89))[0]

    def test_multiple_flags_combine(self):
        flags, triggered = evaluate_vitals(
            _V(systolic_bp=160, diastolic_bp=100, blood_sugar=250, spo2=89))
        assert "HIGH_BP" in flags and "HIGH_SUGAR" in flags and "LOW_SPO2" in flags
        assert len(triggered) == 3

    def test_missing_values_do_not_crash_or_flag(self):
        flags, triggered = evaluate_vitals(_V())
        assert flags == ""
        assert triggered == []

    def test_flags_persist_on_the_model(self, app, patient_user):
        from app.extensions import db
        v = VitalReading(patient_id=patient_user.patient_profile.id,
                         systolic_bp=155, diastolic_bp=98)
        flags, _ = evaluate_vitals(v)
        v.risk_flags = flags
        db.session.add(v)
        db.session.commit()
        assert "HIGH_BP" in VitalReading.query.get(v.id).risk_flags


class TestChatbot:
    def test_emergency_keywords_short_circuit(self):
        r = get_response("I have severe chest pain")
        assert r["urgent"] is True
        assert "emergency" in r["reply"].lower()

    def test_emergency_beats_a_matching_symptom_rule(self):
        # Contains both "fever" (a normal rule) and "can't breathe" (emergency).
        r = get_response("I have a fever and I can't breathe")
        assert r["urgent"] is True

    def test_symptom_rule_matches(self):
        r = get_response("I've had a headache all day")
        assert r["urgent"] is False
        assert "headache" in r["reply"].lower()

    def test_unknown_input_gets_fallback(self):
        r = get_response("what is the capital of France")
        assert r["urgent"] is False
        assert "could you describe" in r["reply"].lower()

    def test_every_response_carries_a_disclaimer(self):
        for msg in ["fever", "chest pain", "xyzzy", ""]:
            assert "not a medical diagnosis" in get_response(msg)["disclaimer"].lower()

    def test_empty_input_does_not_crash(self):
        assert get_response("")["reply"]
        assert get_response(None)["reply"]

    def test_endpoint_requires_login(self, app, client):
        resp = client.post("/api/chatbot", json={"message": "fever"})
        assert resp.status_code in (302, 401)

    def test_endpoint_works_for_logged_in_patient(self, app, client, patient_user):
        from tests.conftest import login
        login(client, "pat@test.com")
        resp = client.post("/api/chatbot", json={"message": "I have a fever"})
        assert resp.status_code == 200
        assert "reply" in resp.get_json()

    def test_endpoint_rejects_empty_message(self, app, client, patient_user):
        from tests.conftest import login
        login(client, "pat@test.com")
        assert client.post("/api/chatbot", json={"message": "   "}).status_code == 400


class TestDocuments:
    def test_qr_generates_png_data_uri(self):
        from app.utils.qr_utils import generate_qr_data_uri, generate_qr_png_bytes
        assert generate_qr_png_bytes("AMAR-EHR|test")[:8] == b"\x89PNG\r\n\x1a\n"
        assert generate_qr_data_uri("AMAR-EHR|test").startswith("data:image/png;base64,")

    def test_export_pdf_is_password_protected(self, app, patient_user):
        import io
        from pypdf import PdfReader
        from app.utils.pdf_generator import generate_records_export_pdf, encrypt_pdf_bytes

        pdf = generate_records_export_pdf(patient_user, patient_user.patient_profile, [], [], [])
        assert pdf[:4] == b"%PDF"

        encrypted = encrypt_pdf_bytes(pdf, "s3cret")
        reader = PdfReader(io.BytesIO(encrypted))
        assert reader.is_encrypted
        # Wrong password fails, right one opens.
        assert reader.decrypt("wrong") == 0
        assert PdfReader(io.BytesIO(encrypted)).decrypt("s3cret") != 0

    def test_file_encryption_round_trip(self, app):
        from app.security.encryption import encrypt_bytes, decrypt_bytes
        original = b"%PDF-1.4 fake lab scan bytes"
        token = encrypt_bytes(original)
        assert original not in token
        assert decrypt_bytes(token) == original
