"""The self-check bands, BMI, and signing in with a phone number."""
import pytest

from app.models.user import User
from app.utils import health_check as hc
from tests.conftest import login, make_user


class _R:
    def __init__(self, **kw):
        for f in ("systolic_bp", "diastolic_bp", "heart_rate", "blood_sugar",
                  "temperature", "spo2", "weight_kg"):
            setattr(self, f, kw.get(f))


class TestBloodPressureBands:
    @pytest.mark.parametrize("sys,dia,band,tone", [
        (110, 70, "Normal", "good"),
        (118, 78, "Normal", "good"),
        (122, 75, "Raised", "caution"),
        (132, 84, "Slightly high", "caution"),
        (145, 92, "High", "bad"),
        (185, 125, "Very high", "bad"),
        (85, 55, "Low", "caution"),
    ])
    def test_bands(self, sys, dia, band, tone):
        r = hc.assess_blood_pressure(sys, dia)
        assert r.band == band and r.tone == tone

    def test_either_number_can_trigger_high(self):
        # Diastolic alone should be enough.
        assert hc.assess_blood_pressure(115, 95).tone == "bad"

    def test_missing_returns_none(self):
        assert hc.assess_blood_pressure(None, 80) is None
        assert hc.assess_blood_pressure(120, None) is None


class TestOtherBands:
    @pytest.mark.parametrize("v,tone", [(99, "good"), (95, "good"), (93, "caution"), (88, "bad")])
    def test_spo2(self, v, tone):
        assert hc.assess_spo2(v).tone == tone

    @pytest.mark.parametrize("v,tone", [(72, "good"), (60, "good"), (55, "caution"),
                                         (45, "bad"), (110, "caution"), (130, "bad")])
    def test_heart_rate(self, v, tone):
        assert hc.assess_heart_rate(v).tone == tone

    @pytest.mark.parametrize("v,tone", [(65, "bad"), (90, "good"), (110, "caution"),
                                         (150, "caution"), (220, "bad")])
    def test_blood_sugar(self, v, tone):
        assert hc.assess_blood_sugar(v).tone == tone

    @pytest.mark.parametrize("v,tone", [(36.6, "good"), (37.8, "caution"),
                                         (38.5, "bad"), (40.0, "bad"), (34.5, "bad")])
    def test_temperature(self, v, tone):
        assert hc.assess_temperature(v).tone == tone

    def test_fever_is_named_plainly(self):
        assert hc.assess_temperature(38.5).band == "Fever"


class TestBMI:
    def test_computation(self):
        # 70 kg at 170 cm -> 24.2
        assert hc.compute_bmi(70, 170) == 24.2

    def test_rejects_nonsense(self):
        assert hc.compute_bmi(70, None) is None
        assert hc.compute_bmi(None, 170) is None
        assert hc.compute_bmi(0, 170) is None
        assert hc.compute_bmi(70, -5) is None
        assert hc.compute_bmi(70, 1.7) is None      # metres, not cm
        assert hc.compute_bmi(700, 170) is None     # implausible weight

    @pytest.mark.parametrize("bmi,band,tone", [
        (15.0, "Very underweight", "bad"),
        (17.5, "Underweight", "caution"),
        (22.0, "Healthy weight", "good"),
        (24.9, "Healthy weight", "good"),
        (27.0, "Overweight", "caution"),
        (33.0, "Obese", "bad"),
    ])
    def test_bands(self, bmi, band, tone):
        r = hc.assess_bmi(bmi)
        assert r.band == band and r.tone == tone

    def test_boundaries(self):
        assert hc.assess_bmi(18.5).tone == "good"
        assert hc.assess_bmi(18.4).tone == "caution"
        assert hc.assess_bmi(25.0).tone == "caution"


class TestSummary:
    def test_all_good(self):
        results = hc.assess_reading(
            _R(systolic_bp=115, diastolic_bp=75, heart_rate=70, spo2=98,
               blood_sugar=90, temperature=36.6, weight_kg=70), height_cm=170)
        s = hc.overall(results)
        assert s["tone"] == "good"
        assert s["counts"]["good"] == len(results)

    def test_one_bad_dominates(self):
        results = hc.assess_reading(
            _R(systolic_bp=115, diastolic_bp=75, spo2=85), height_cm=170)
        assert hc.overall(results)["tone"] == "bad"

    def test_caution_when_no_bad(self):
        results = hc.assess_reading(_R(systolic_bp=132, diastolic_bp=84, spo2=98))
        assert hc.overall(results)["tone"] == "caution"

    def test_missing_values_are_skipped(self):
        results = hc.assess_reading(_R(spo2=98))
        assert len(results) == 1 and results[0].key == "spo2"

    def test_bmi_needs_height(self):
        keys = {r.key for r in hc.assess_reading(_R(weight_kg=70), height_cm=None)}
        assert "bmi" not in keys
        keys = {r.key for r in hc.assess_reading(_R(weight_kg=70), height_cm=170)}
        assert "bmi" in keys

    def test_empty_reading(self):
        assert hc.assess_reading(_R()) == []
        assert hc.overall([])["tone"] is None

    def test_every_result_explains_itself(self):
        results = hc.assess_reading(
            _R(systolic_bp=150, diastolic_bp=95, heart_rate=70, spo2=98,
               blood_sugar=90, temperature=36.6, weight_kg=70), height_cm=170)
        for r in results:
            assert r.explanation and r.advice
            assert r.tone_label in ("Good", "Watch", "Needs attention")


class TestPhoneNormalisation:
    @pytest.mark.parametrize("raw,expected", [
        ("+1 (555) 014-2", "+15550142"),
        ("+1-555-0142", "+15550142"),
        ("  +15550142 ", "+15550142"),
        ("5550142", "5550142"),
        ("", None),
        (None, None),
    ])
    def test_normalise(self, raw, expected):
        assert User.normalize_phone(raw) == expected

    def test_email_detection(self):
        assert User.looks_like_email("a@b.com")
        assert not User.looks_like_email("+15550142")


class TestSignInWithPhone:
    def test_can_sign_in_with_phone(self, app, client):
        make_user("phone@test.com", "Phone User", "patient", phone="+15559001")
        resp = login(client, "+15559001")
        assert b"Hello" in resp.data or b"Home" in resp.data

    def test_phone_formatting_is_ignored(self, app, client):
        make_user("phone2@test.com", "Phone Two", "patient", phone="+15559002")
        # Typed with brackets, spaces and dashes.
        resp = login(client, "+1 (555) 900-2")
        assert b"don't match" not in resp.data

    def test_email_still_works(self, app, client, patient_user):
        resp = login(client, "pat@test.com")
        assert b"don't match" not in resp.data

    def test_unknown_phone_is_rejected(self, app, client, patient_user):
        resp = login(client, "+19999999999")
        assert b"don't match" in resp.data

    def test_wrong_password_with_phone_is_rejected(self, app, client):
        make_user("phone3@test.com", "Phone Three", "patient", phone="+15559003")
        resp = login(client, "+15559003", password="WrongPass123")
        assert b"don't match" in resp.data

    def test_duplicate_phone_is_refused_at_signup(self, app, client):
        make_user("first@test.com", "First", "patient", phone="+15559100")
        resp = client.post("/auth/register", data={
            "full_name": "Second Person", "email": "second@test.com",
            "phone": "+1 555 9100", "role": "patient",
            "password": "GoodPass123", "confirm_password": "GoodPass123",
        }, follow_redirects=True)
        assert b"already registered" in resp.data
        assert User.query.filter_by(email="second@test.com").first() is None

    def test_signup_without_phone_still_works(self, app, client):
        resp = client.post("/auth/register", data={
            "full_name": "No Phone", "email": "nophone@test.com", "phone": "",
            "role": "patient", "password": "GoodPass123", "confirm_password": "GoodPass123",
        }, follow_redirects=True)
        assert User.query.filter_by(email="nophone@test.com").first() is not None

    def test_multiple_users_without_phone_allowed(self, app, client):
        """NULL phones must not collide under the unique constraint."""
        for i in range(3):
            client.post("/auth/register", data={
                "full_name": f"User {i}", "email": f"u{i}@test.com", "phone": "",
                "role": "patient", "password": "GoodPass123", "confirm_password": "GoodPass123",
            })
        assert User.query.filter_by(phone=None).count() >= 3
