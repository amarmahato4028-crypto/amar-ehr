"""Security-critical behaviour: RBAC, encryption, lockout, audit chain."""
from datetime import timedelta

from app.extensions import db
from app.models.user import User
from app.models.medical_record import MedicalRecord
from app.models.audit_log import AuditLog
from app.security.hashchain import verify_chain, GENESIS_HASH
from app.utils.timeutils import utcnow
from tests.conftest import login, link


class TestPasswordHashing:
    def test_password_is_hashed_not_plaintext(self, app, patient_user):
        assert patient_user.password_hash != "TestPass123"
        assert "TestPass123" not in patient_user.password_hash
        assert patient_user.check_password("TestPass123")
        assert not patient_user.check_password("WrongPass123")


class TestAccountLockout:
    def test_lockout_after_max_attempts(self, app, client, patient_user):
        max_attempts = app.config["MAX_LOGIN_ATTEMPTS"]
        for _ in range(max_attempts):
            client.post("/auth/login", data={"email": "pat@test.com", "password": "wrong"})
        user = User.query.filter_by(email="pat@test.com").first()
        assert user.is_locked()

        # Even the correct password is refused while locked.
        resp = login(client, "pat@test.com")
        assert b"locked" in resp.data.lower()

    def test_successful_login_resets_counter(self, app, client, patient_user):
        client.post("/auth/login", data={"email": "pat@test.com", "password": "wrong"})
        login(client, "pat@test.com")
        user = User.query.filter_by(email="pat@test.com").first()
        assert user.failed_login_attempts == 0

    def test_deactivated_account_cannot_log_in(self, app, client, patient_user):
        patient_user.is_active_account = False
        db.session.commit()
        resp = login(client, "pat@test.com")
        assert b"deactivated" in resp.data.lower()


class TestFieldEncryption:
    def test_diagnosis_is_ciphertext_at_rest(self, app, doctor_user, patient_user):
        link(doctor_user, patient_user)
        rec = MedicalRecord(patient_id=patient_user.patient_profile.id,
                            doctor_id=doctor_user.doctor_profile.id,
                            diagnosis="Hypertension stage 2",
                            notes="Patient reports headaches.")
        db.session.add(rec)
        db.session.commit()
        rec_id = rec.id
        db.session.expunge_all()

        # Read the raw column, bypassing the EncryptedString decorator.
        raw = db.session.execute(
            db.text("SELECT diagnosis, notes FROM medical_records WHERE id = :i"),
            {"i": rec_id}).fetchone()
        assert "Hypertension" not in raw[0]
        assert "headaches" not in raw[1]
        assert raw[0].startswith("gAAAAA")  # Fernet token prefix

        # But the ORM transparently decrypts it.
        assert MedicalRecord.query.get(rec_id).diagnosis == "Hypertension stage 2"


class TestRBAC:
    def test_patient_cannot_reach_doctor_area(self, app, client, patient_user):
        login(client, "pat@test.com")
        assert client.get("/doctor/dashboard").status_code == 403

    def test_patient_cannot_reach_admin_area(self, app, client, patient_user):
        login(client, "pat@test.com")
        assert client.get("/admin/audit-trail").status_code == 403

    def test_doctor_cannot_open_unassigned_patient(self, app, client, doctor_user, patient_user):
        login(client, "doc@test.com")
        # No appointment linking them yet.
        resp = client.get(f"/doctor/patients/{patient_user.patient_profile.id}")
        assert resp.status_code == 403

    def test_doctor_can_open_assigned_patient(self, app, client, doctor_user, patient_user):
        link(doctor_user, patient_user)
        login(client, "doc@test.com")
        resp = client.get(f"/doctor/patients/{patient_user.patient_profile.id}")
        assert resp.status_code == 200

    def test_patient_cannot_read_another_patients_labs(self, app, client, patient_user,
                                                        other_patient_user):
        login(client, "pat@test.com")
        resp = client.get(f"/records/lab-reports/patient/{other_patient_user.patient_profile.id}")
        assert resp.status_code == 403

    def test_anonymous_is_redirected_to_login(self, app, client):
        resp = client.get("/patient/dashboard")
        assert resp.status_code == 302
        assert "/auth/login" in resp.headers["Location"]


class Test2FAEnforcement:
    def test_doctor_without_2fa_is_forced_to_setup(self, app, client):
        from tests.conftest import make_user
        make_user("nodoc@test.com", "No TwoFA", "doctor", two_fa=False)
        login(client, "nodoc@test.com")
        resp = client.get("/doctor/dashboard")
        assert resp.status_code == 302
        assert "setup_2fa" in resp.headers["Location"] or "2fa" in resp.headers["Location"]

    def test_patient_is_not_forced_into_2fa(self, app, client, patient_user):
        login(client, "pat@test.com")
        assert client.get("/patient/dashboard").status_code == 200


class TestAuditChain:
    def test_chain_is_valid_after_activity(self, app, client, patient_user):
        login(client, "pat@test.com")
        client.get("/patient/dashboard")
        client.get("/patient/records")
        entries = AuditLog.query.order_by(AuditLog.id.asc()).all()
        assert len(entries) > 1
        ok, broken = verify_chain(entries)
        assert ok, f"chain broken at {broken}"

    def test_first_entry_chains_from_genesis(self, app, client, patient_user):
        login(client, "pat@test.com")
        first = AuditLog.query.order_by(AuditLog.id.asc()).first()
        assert first.prev_hash == GENESIS_HASH

    def test_tampering_is_detected(self, app, client, patient_user):
        login(client, "pat@test.com")
        client.get("/patient/dashboard")
        entries = AuditLog.query.order_by(AuditLog.id.asc()).all()
        assert verify_chain(entries)[0]

        # Someone edits history directly in the database.
        victim = entries[len(entries) // 2]
        db.session.execute(
            db.text("UPDATE audit_logs SET action = :a WHERE id = :i"),
            {"a": "TOTALLY_INNOCENT", "i": victim.id})
        db.session.commit()
        db.session.expunge_all()

        entries = AuditLog.query.order_by(AuditLog.id.asc()).all()
        ok, broken_id = verify_chain(entries)
        assert not ok
        assert broken_id == victim.id

    def test_deleting_a_row_is_detected(self, app, client, patient_user):
        login(client, "pat@test.com")
        client.get("/patient/dashboard")
        client.get("/patient/records")
        entries = AuditLog.query.order_by(AuditLog.id.asc()).all()
        victim = entries[1]
        db.session.execute(db.text("DELETE FROM audit_logs WHERE id = :i"), {"i": victim.id})
        db.session.commit()
        db.session.expunge_all()

        ok, _ = verify_chain(AuditLog.query.order_by(AuditLog.id.asc()).all())
        assert not ok

    def test_access_denial_is_logged(self, app, client, patient_user):
        login(client, "pat@test.com")
        client.get("/admin/audit-trail")  # 403
        denied = AuditLog.query.filter_by(action="ACCESS_DENIED").first()
        assert denied is not None
