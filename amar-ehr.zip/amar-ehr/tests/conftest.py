import os
import itertools
import tempfile
import pytest

os.environ["FLASK_ENV"] = "development"
os.environ["WTF_CSRF_ENABLED"] = "false"
# Deterministic keys so tests don't depend on instance/keys.env
os.environ.setdefault("FIELD_ENCRYPTION_KEY", "8ZQm7Xq0hV3nJ5rT1yWc9bL2sD4fG6kP8aN0eR2uI3o=")
os.environ.setdefault("FILE_ENCRYPTION_KEY", "pL9wQ2eR5tY7uI0oP3aS6dF8gH1jK4lZ7xC0vB3nM5Q=")

from app import create_app
from app.extensions import db as _db
from app.models.user import User
from app.models.patient import PatientProfile
from app.models.doctor import DoctorProfile
from app.models.appointment import Appointment


@pytest.fixture
def app():
    fd, db_path = tempfile.mkstemp(suffix=".db")
    os.close(fd)

    application = create_app("development")
    application.config.update(
        TESTING=True,
        WTF_CSRF_ENABLED=False,
        SQLALCHEMY_DATABASE_URI=f"sqlite:///{db_path}",
        RATELIMIT_ENABLED=False,
        MAIL_SUPPRESS_SEND=True,
    )

    with application.app_context():
        _db.create_all()
        yield application
        _db.session.remove()
        _db.drop_all()

    os.unlink(db_path)


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def db(app):
    return _db


_phone_seq = itertools.count(1)


def make_user(email, name, role, password="TestPass123", two_fa=True, phone=None):
    """2FA defaults to already-enabled for doctor/admin so tests aren't
    bounced by the enforcement gate. Phone is unique per user because it
    can be used to sign in."""
    phone = User.normalize_phone(phone or f"+1555{next(_phone_seq):06d}")
    u = User(email=email, full_name=name, role=role, phone=phone)
    u.set_password(password)
    if role in ("doctor", "admin"):
        u.two_fa_enabled = two_fa
        u.totp_secret = "JBSWY3DPEHPK3PXP"
    _db.session.add(u)
    _db.session.flush()
    if role == "patient":
        _db.session.add(PatientProfile(user_id=u.id, blood_group="O+"))
    elif role == "doctor":
        _db.session.add(DoctorProfile(user_id=u.id, specialization="Cardiology"))
    _db.session.commit()
    return u


@pytest.fixture
def patient_user(app):
    return make_user("pat@test.com", "Pat Patient", "patient")


@pytest.fixture
def other_patient_user(app):
    return make_user("other@test.com", "Other Patient", "patient")


@pytest.fixture
def doctor_user(app):
    return make_user("doc@test.com", "Dee Doctor", "doctor")


@pytest.fixture
def admin_user(app):
    return make_user("admin@test.com", "Ada Admin", "admin")


def login(client, identifier, password="TestPass123"):
    """`identifier` may be an email address or a phone number."""
    return client.post("/auth/login",
                       data={"identifier": identifier, "password": password},
                       follow_redirects=True)


def link(doctor_user, patient_user, when=None):
    """Create the appointment that makes a patient 'assigned' to a doctor."""
    from app.utils.timeutils import utcnow
    from datetime import timedelta
    appt = Appointment(patient_id=patient_user.patient_profile.id,
                       doctor_id=doctor_user.doctor_profile.id,
                       scheduled_at=when or (utcnow() + timedelta(days=1)),
                       reason="Checkup", status="scheduled")
    _db.session.add(appt)
    _db.session.commit()
    return appt
