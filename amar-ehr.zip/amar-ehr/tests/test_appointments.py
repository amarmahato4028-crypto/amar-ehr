"""Appointment booking, the timezone handling around it, and status updates."""
from datetime import datetime, timedelta

from app.extensions import db
from app.models.appointment import Appointment
from app.utils.timeutils import utcnow, local_to_utc, to_iso_z
from tests.conftest import login, link


class TestTimezoneHandling:
    """Regression tests for the naive/aware datetime bug: an appointment a
    couple of hours in the future used to vanish from 'Upcoming' for any
    user west of UTC, because a naive local value was compared against an
    aware UTC one."""

    def test_local_to_utc_converts_west_of_utc(self):
        local = datetime(2026, 8, 15, 10, 0)   # 10:00 EDT
        assert local_to_utc(local, 240) == datetime(2026, 8, 15, 14, 0)  # 14:00 UTC

    def test_local_to_utc_converts_east_of_utc(self):
        local = datetime(2026, 8, 15, 17, 30)  # 17:30 IST
        assert local_to_utc(local, -330) == datetime(2026, 8, 15, 12, 0)  # 12:00 UTC

    def test_local_to_utc_rejects_absurd_offset(self):
        local = datetime(2026, 8, 15, 10, 0)
        assert local_to_utc(local, 999999) == local  # falls back to treating as UTC

    def test_local_to_utc_handles_missing_offset(self):
        local = datetime(2026, 8, 15, 10, 0)
        assert local_to_utc(local, None) == local
        assert local_to_utc(local, "") == local

    def test_utcnow_is_naive(self):
        assert utcnow().tzinfo is None

    def test_stored_datetimes_are_naive(self, app, patient_user, doctor_user):
        appt = link(doctor_user, patient_user)
        assert appt.scheduled_at.tzinfo is None
        assert appt.created_at.tzinfo is None

    def test_iso_z_format(self):
        assert to_iso_z(datetime(2026, 8, 15, 14, 30, 5)) == "2026-08-15T14:30:05Z"

    def test_near_future_appointment_shows_as_upcoming(self, app, client,
                                                       patient_user, doctor_user):
        """The exact case that used to fail: booked 2 hours out."""
        link(doctor_user, patient_user, when=utcnow() + timedelta(hours=2))
        login(client, "pat@test.com")
        resp = client.get("/patient/dashboard")
        assert resp.status_code == 200
        # 1 upcoming appointment, not 0
        upcoming = (Appointment.query
                    .filter(Appointment.scheduled_at >= utcnow()).all())
        assert len(upcoming) == 1

    def test_past_appointment_excluded_from_upcoming(self, app, patient_user, doctor_user):
        link(doctor_user, patient_user, when=utcnow() - timedelta(hours=2))
        upcoming = Appointment.query.filter(Appointment.scheduled_at >= utcnow()).all()
        assert len(upcoming) == 0


class TestBooking:
    def test_patient_can_book(self, app, client, patient_user, doctor_user):
        login(client, "pat@test.com")
        future_local = (datetime.now() + timedelta(days=3)).strftime("%Y-%m-%dT%H:%M")
        resp = client.post("/patient/appointments/book", data={
            "doctor_id": doctor_user.doctor_profile.id,
            "scheduled_at": future_local,
            "tz_offset": "240",
            "reason": "Annual checkup",
        }, follow_redirects=True)
        assert resp.status_code == 200
        assert Appointment.query.count() == 1

    def test_booking_in_the_past_is_rejected(self, app, client, patient_user, doctor_user):
        login(client, "pat@test.com")
        past_local = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M")
        client.post("/patient/appointments/book", data={
            "doctor_id": doctor_user.doctor_profile.id,
            "scheduled_at": past_local,
            "tz_offset": "0",
            "reason": "Time travel",
        })
        assert Appointment.query.count() == 0

    def test_patient_cannot_cancel_another_patients_appointment(
            self, app, client, patient_user, other_patient_user, doctor_user):
        appt = link(doctor_user, other_patient_user)
        login(client, "pat@test.com")
        resp = client.post(f"/patient/appointments/{appt.id}/cancel")
        assert resp.status_code == 403
        assert Appointment.query.get(appt.id).status == "scheduled"


class TestDoctorStatusUpdates:
    def test_doctor_can_complete_appointment(self, app, client, doctor_user, patient_user):
        appt = link(doctor_user, patient_user)
        login(client, "doc@test.com")
        client.post(f"/doctor/appointments/{appt.id}/status",
                    data={"status": "completed"}, follow_redirects=True)
        assert Appointment.query.get(appt.id).status == "completed"

    def test_invalid_status_is_rejected(self, app, client, doctor_user, patient_user):
        appt = link(doctor_user, patient_user)
        login(client, "doc@test.com")
        client.post(f"/doctor/appointments/{appt.id}/status",
                    data={"status": "deleted_lol"}, follow_redirects=True)
        assert Appointment.query.get(appt.id).status == "scheduled"

    def test_doctor_cannot_touch_another_doctors_appointment(
            self, app, client, doctor_user, patient_user):
        from tests.conftest import make_user
        other_doc = make_user("doc2@test.com", "Other Doc", "doctor")
        appt = link(other_doc, patient_user)
        login(client, "doc@test.com")
        resp = client.post(f"/doctor/appointments/{appt.id}/status", data={"status": "completed"})
        assert resp.status_code == 403
