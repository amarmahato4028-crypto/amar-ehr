from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user

from app.extensions import limiter
from app.utils.chatbot import get_response
from app.security.decorators import log_action

api_bp = Blueprint("api", __name__)


@api_bp.route("/chatbot", methods=["POST"])
@login_required
@limiter.limit("30 per minute")
def chatbot():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "")[:500]
    if not message.strip():
        return jsonify({"error": "message is required"}), 400
    result = get_response(message)
    log_action(current_user.id, "CHATBOT_QUERY", "chatbot", None, details=message[:200])
    return jsonify(result)
