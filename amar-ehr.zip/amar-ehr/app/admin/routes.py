from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user

from app.extensions import db
from app.models.user import User
from app.models.audit_log import AuditLog
from app.security.decorators import role_required, log_action
from app.security.hashchain import verify_chain

admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/dashboard")
@login_required
@role_required("admin")
def dashboard():
    total_users = User.query.count()
    total_patients = User.query.filter_by(role="patient").count()
    total_doctors = User.query.filter_by(role="doctor").count()
    recent_logs = AuditLog.query.order_by(AuditLog.id.desc()).limit(15).all()
    log_action(current_user.id, "VIEW_ADMIN_DASHBOARD", "admin", None)
    return render_template("admin/dashboard.html", total_users=total_users, total_patients=total_patients,
                            total_doctors=total_doctors, recent_logs=recent_logs)


@admin_bp.route("/users")
@login_required
@role_required("admin")
def users():
    all_users = User.query.order_by(User.created_at.desc()).all()
    return render_template("admin/users.html", users=all_users)


@admin_bp.route("/users/<int:user_id>/toggle-active", methods=["POST"])
@login_required
@role_required("admin")
def toggle_active(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot deactivate your own account.", "danger")
        return redirect(url_for("admin.users"))
    user.is_active_account = not user.is_active_account
    db.session.commit()
    log_action(current_user.id, "TOGGLE_USER_ACTIVE", "user", user.id,
               details=f"active={user.is_active_account}")
    flash(f"{user.email} is now {'active' if user.is_active_account else 'deactivated'}.", "info")
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/unlock", methods=["POST"])
@login_required
@role_required("admin")
def unlock_user(user_id):
    user = User.query.get_or_404(user_id)
    user.locked_until = None
    user.failed_login_attempts = 0
    db.session.commit()
    log_action(current_user.id, "UNLOCK_USER", "user", user.id)
    flash(f"{user.email} unlocked.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/audit-trail")
@login_required
@role_required("admin")
def audit_trail():
    """Filterable audit trail. 'Who accessed what, when' is only useful if
    you can actually narrow it down — an unfiltered 40-per-page list is
    unusable once the log has a few thousand entries."""
    page = request.args.get("page", 1, type=int)
    user_q = request.args.get("user", "").strip()
    action_q = request.args.get("action", "").strip()

    query = AuditLog.query
    if user_q:
        query = query.join(User).filter(User.email.ilike(f"%{user_q}%"))
    if action_q:
        query = query.filter(AuditLog.action == action_q)

    pagination = (query.order_by(AuditLog.id.desc())
                  .paginate(page=page, per_page=40, error_out=False))

    # Distinct actions present, for the filter dropdown.
    actions = [row[0] for row in db.session.query(AuditLog.action).distinct().order_by(AuditLog.action).all()]

    return render_template("admin/audit_trail.html", pagination=pagination,
                            actions=actions, user_q=user_q, action_q=action_q)


@admin_bp.route("/audit-trail/verify")
@login_required
@role_required("admin")
def verify_audit_chain():
    entries = AuditLog.query.order_by(AuditLog.id.asc()).all()
    is_valid, broken_id = verify_chain(entries)
    log_action(current_user.id, "VERIFY_AUDIT_CHAIN", "admin", None,
               details=f"valid={is_valid} broken_id={broken_id}")
    return render_template("admin/verify_chain.html", is_valid=is_valid, broken_id=broken_id,
                            total_entries=len(entries))
