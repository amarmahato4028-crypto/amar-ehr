from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo, Regexp, Optional


class RegisterForm(FlaskForm):
    full_name = StringField("Your full name", validators=[DataRequired(), Length(max=120)])
    email = StringField("Email address", validators=[DataRequired(), Email(), Length(max=255)],
                        description="You'll use this to sign in")
    phone = StringField("Mobile number", validators=[
        Optional(), Length(max=30),
        Regexp(r"^\+?[\d\s().-]{7,20}$",
               message="Please enter a valid mobile number, e.g. +1 555 0142."),
    ], description="Optional — you can sign in with this, and we'll use it for reminders")
    role = SelectField("I am a", choices=[("patient", "Patient"), ("doctor", "Doctor")])
    password = PasswordField("Create a password", validators=[
        DataRequired(), Length(min=8, message="Please use at least 8 characters."),
        Regexp(r"^(?=.*[A-Za-z])(?=.*\d).+$",
               message="Please include at least one letter and one number."),
    ], description="At least 8 characters, with a letter and a number")
    confirm_password = PasswordField("Type your password again", validators=[
        DataRequired(), EqualTo("password", message="These passwords don't match.")])
    submit = SubmitField("Create my account")


class LoginForm(FlaskForm):
    # One box accepts either an email address or a mobile number — asking
    # users to pick the right field first is friction they don't need.
    identifier = StringField("Email or mobile number",
                             validators=[DataRequired(message="Please enter your email or mobile number."),
                                          Length(max=255)],
                             description="Whichever you signed up with")
    password = PasswordField("Password", validators=[DataRequired()])
    totp_code = StringField("6-digit code", validators=[Length(max=10)],
                            description="Only if you've set up 2-step verification")
    submit = SubmitField("Sign in")


class Enable2FAForm(FlaskForm):
    totp_code = StringField("Enter the 6-digit code from your app",
                            validators=[DataRequired(), Length(min=6, max=6)])
    submit = SubmitField("Turn on 2-step verification")
