import pyotp
from datetime import datetime, timezone
from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, login_required, current_user

from app.extensions import db, limiter
from app.models.user import User
from app.models.patient import PatientProfile
from app.models.doctor import DoctorProfile
from app.auth.forms import RegisterForm, LoginForm, Enable2FAForm
from app.security.decorators import log_action
from app.utils.qr_utils import generate_qr_data_uri

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")

ROLES_REQUIRING_2FA = {"doctor", "admin"}


def render_entry(active_tab, login_form=None, register_form=None):
    """Sign-in and sign-up share one page, so both routes render the same
    template. The form that wasn't submitted is built with formdata=None,
    otherwise it would try to validate the other form's POST and show
    spurious errors."""
    return render_template(
        "auth/entry.html",
        active_tab=active_tab,
        login_form=login_form if login_form is not None else LoginForm(formdata=None),
        register_form=register_form if register_form is not None else RegisterForm(formdata=None),
    )


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    form = RegisterForm()
    if form.validate_on_submit():
        email = form.email.data.lower().strip()
        phone = User.normalize_phone(form.phone.data)

        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists. Try signing in instead.", "danger")
            return render_entry("register", register_form=form)

        # Phone can be used to sign in, so it has to identify one account.
        if phone and User.query.filter_by(phone=phone).first():
            flash("That mobile number is already registered. Try signing in instead.", "danger")
            return render_entry("register", register_form=form)

        user = User(
            email=email,
            full_name=form.full_name.data.strip(),
            phone=phone,
            role=form.role.data,
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.flush()  # get user.id before creating profile

        if user.role == "patient":
            db.session.add(PatientProfile(user_id=user.id))
        elif user.role == "doctor":
            db.session.add(DoctorProfile(user_id=user.id, specialization="General Medicine"))

        db.session.commit()
        log_action(user.id, "REGISTER", "user", user.id, details=f"role={user.role}")

        flash("Account created. Please sign in.", "success")
        if user.role in ROLES_REQUIRING_2FA:
            flash("As a doctor account, you'll be asked to set up two-factor authentication after your first login.", "info")
        return redirect(url_for("auth.login"))
    return render_entry("register", register_form=form)


@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("10 per minute")
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    form = LoginForm()
    if form.validate_on_submit():
        # Accepts an email address or a mobile number in the same box.
        user = User.find_by_login(form.identifier.data)

        if user and user.is_locked():
            flash("Account temporarily locked due to repeated failed attempts. Try again later.", "danger")
            log_action(user.id, "LOGIN_BLOCKED_LOCKED", "user", user.id)
            return render_entry("login", login_form=form)

        # Deactivated accounts: Flask-Login's login_user() would silently
        # refuse (is_active is False), leaving the user in a confusing
        # redirect loop with no explanation. Reject explicitly instead —
        # but only after the password check below, so this endpoint can't
        # be used to enumerate which accounts exist.

        if not user or not user.check_password(form.password.data):
            if user:
                max_attempts = current_app_config("MAX_LOGIN_ATTEMPTS")
                lockout_minutes = current_app_config("LOCKOUT_MINUTES")
                user.register_failed_login(max_attempts, lockout_minutes)
                db.session.commit()
                log_action(user.id, "LOGIN_FAILED", "user", user.id)
            # Deliberately vague — naming which half was wrong would let
            # someone probe for registered emails/numbers.
            flash("Those details don't match an account. Please check and try again.", "danger")
            return render_entry("login", login_form=form)

        if not user.is_active_account:
            flash("This account has been deactivated. Please contact an administrator.", "danger")
            log_action(user.id, "LOGIN_BLOCKED_DEACTIVATED", "user", user.id)
            return render_entry("login", login_form=form)

        if user.two_fa_enabled:
            code = (form.totp_code.data or "").strip()
            totp = pyotp.TOTP(user.totp_secret)
            if not code or not totp.verify(code, valid_window=1):
                flash("Valid 2FA code required.", "warning")
                log_action(user.id, "LOGIN_2FA_FAILED", "user", user.id)
                return render_entry("login", login_form=form)

        user.register_successful_login()
        db.session.commit()
        login_user(user, remember=False)
        session.permanent = True
        log_action(user.id, "LOGIN_SUCCESS", "user", user.id)

        if user.role in ROLES_REQUIRING_2FA and not user.two_fa_enabled:
            flash("Two-factor authentication is required for your account role. Please set it up now.", "warning")
            return redirect(url_for("auth.setup_2fa"))

        return redirect(url_for("main.dashboard"))
    return render_entry("login", login_form=form)


def current_app_config(key):
    from flask import current_app
    return current_app.config[key]


@auth_bp.route("/logout")
@login_required
def logout():
    log_action(current_user.id, "LOGOUT", "user", current_user.id)
    logout_user()
    flash("You have been signed out.", "info")
    return redirect(url_for("auth.login"))


@auth_bp.route("/2fa/setup", methods=["GET", "POST"])
@login_required
def setup_2fa():
    if current_user.two_fa_enabled:
        flash("2FA is already enabled on your account.", "info")
        return redirect(url_for("main.dashboard"))

    if not current_user.totp_secret:
        current_user.totp_secret = pyotp.random_base32()
        db.session.commit()

    totp = pyotp.TOTP(current_user.totp_secret)
    provisioning_uri = totp.provisioning_uri(name=current_user.email, issuer_name="Amar EHR")
    qr_data_uri = generate_qr_data_uri(provisioning_uri)

    form = Enable2FAForm()
    if form.validate_on_submit():
        if totp.verify(form.totp_code.data.strip(), valid_window=1):
            current_user.two_fa_enabled = True
            db.session.commit()
            log_action(current_user.id, "2FA_ENABLED", "user", current_user.id)
            flash("Two-factor authentication enabled.", "success")
            return redirect(url_for("main.dashboard"))
        flash("Invalid code. Please try again.", "danger")

    return render_template("auth/setup_2fa.html", form=form, qr_data_uri=qr_data_uri,
                            secret=current_user.totp_secret)


@auth_bp.route("/2fa/disable", methods=["POST"])
@login_required
def disable_2fa():
    if current_user.role in ROLES_REQUIRING_2FA:
        flash("2FA cannot be disabled for doctor/admin accounts.", "danger")
        return redirect(url_for("main.dashboard"))
    current_user.two_fa_enabled = False
    current_user.totp_secret = None
    db.session.commit()
    log_action(current_user.id, "2FA_DISABLED", "user", current_user.id)
    flash("Two-factor authentication disabled.", "info")
    return redirect(url_for("main.dashboard"))
