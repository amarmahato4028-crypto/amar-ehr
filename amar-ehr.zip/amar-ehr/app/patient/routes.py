from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, send_file, jsonify
from flask_login import login_required, current_user
import io

from app.extensions import db
from app.models.doctor import DoctorProfile
from app.models.appointment import Appointment
from app.models.medical_record import MedicalRecord
from app.models.prescription import Prescription
from app.models.vitals import VitalReading
from app.security.decorators import role_required, log_action
from app.patient.forms import (ProfileForm, BookAppointmentForm, SelfVitalsForm,
                                ExportPasswordForm, SelfCheckForm)
from app.utils.health_check import assess_reading, overall
from app.utils.qr_utils import generate_qr_data_uri
from app.utils.anomaly import evaluate_vitals
from app.utils.timeutils import utcnow, local_to_utc
from app.utils.forms import populate_model
from app.utils.pdf_generator import generate_records_export_pdf, encrypt_pdf_bytes

patient_bp = Blueprint("patient", __name__)


def _own_profile_or_403():
    profile = current_user.patient_profile
    if not profile:
        abort(403)
    return profile


@patient_bp.route("/dashboard")
@login_required
@role_required("patient")
def dashboard():
    profile = _own_profile_or_403()
    upcoming = (Appointment.query.filter_by(patient_id=profile.id)
                .filter(Appointment.scheduled_at >= utcnow())
                .order_by(Appointment.scheduled_at.asc()).limit(5).all())
    recent_vitals = (VitalReading.query.filter_by(patient_id=profile.id)
                      .order_by(VitalReading.recorded_at.desc()).limit(10).all())
    active_flags = [v for v in recent_vitals if v.risk_flags]
    log_action(current_user.id, "VIEW_DASHBOARD", "patient_profile", profile.id)
    return render_template("patient/dashboard.html", profile=profile, upcoming=upcoming,
                            recent_vitals=recent_vitals, active_flags=active_flags)


@patient_bp.route("/vitals/chart-data")
@login_required
@role_required("patient")
def vitals_chart_data():
    profile = _own_profile_or_403()
    readings = (VitalReading.query.filter_by(patient_id=profile.id)
                .order_by(VitalReading.recorded_at.asc()).limit(30).all())
    return jsonify({
        "labels": [r.recorded_at.strftime("%m-%d") for r in readings],
        "systolic": [r.systolic_bp for r in readings],
        "diastolic": [r.diastolic_bp for r in readings],
        "sugar": [r.blood_sugar for r in readings],
        "heart_rate": [r.heart_rate for r in readings],
    })


@patient_bp.route("/profile", methods=["GET", "POST"])
@login_required
@role_required("patient")
def profile():
    profile = _own_profile_or_403()
    form = ProfileForm(obj=profile)
    if form.validate_on_submit():
        populate_model(form, profile)
        db.session.commit()
        log_action(current_user.id, "UPDATE_PROFILE", "patient_profile", profile.id)
        flash("Profile updated.", "success")
        return redirect(url_for("patient.profile"))
    return render_template("patient/profile.html", form=form, profile=profile)


@patient_bp.route("/doctors")
@login_required
@role_required("patient")
def doctors():
    """Browsable doctor directory, filterable by specialization — the spec
    calls for doctor profiles & specializations, but previously the only
    place a patient could see them was the booking dropdown."""
    spec = request.args.get("specialization", "").strip()
    query = DoctorProfile.query
    if spec:
        query = query.filter(DoctorProfile.specialization.ilike(f"%{spec}%"))
    doctor_list = query.order_by(DoctorProfile.specialization.asc()).all()
    specializations = sorted({d.specialization for d in DoctorProfile.query.all() if d.specialization})
    return render_template("patient/doctors.html", doctors=doctor_list,
                            specializations=specializations, current_spec=spec)


@patient_bp.route("/appointments/book", methods=["GET", "POST"])
@login_required
@role_required("patient")
def book_appointment():
    profile = _own_profile_or_403()
    form = BookAppointmentForm()
    form.doctor_id.choices = [
        (d.id, f"Dr. {d.user.full_name} — {d.specialization}") for d in DoctorProfile.query.all()
    ]
    if form.validate_on_submit():
        # The browser submits local wall-clock time; store naive UTC so it
        # compares correctly against utcnow() in the upcoming/reminder queries.
        scheduled_utc = local_to_utc(form.scheduled_at.data, form.tz_offset.data)
        if scheduled_utc <= utcnow():
            flash("Please choose a future date and time.", "danger")
            return render_template("patient/book_appointment.html", form=form)

        appt = Appointment(patient_id=profile.id, doctor_id=form.doctor_id.data,
                            scheduled_at=scheduled_utc, reason=form.reason.data, status="scheduled")
        db.session.add(appt)
        db.session.commit()
        log_action(current_user.id, "BOOK_APPOINTMENT", "appointment", appt.id)
        flash("Appointment booked.", "success")
        return redirect(url_for("patient.dashboard"))
    return render_template("patient/book_appointment.html", form=form)


@patient_bp.route("/appointments")
@login_required
@role_required("patient")
def appointments():
    profile = _own_profile_or_403()
    appts = Appointment.query.filter_by(patient_id=profile.id).order_by(Appointment.scheduled_at.desc()).all()
    return render_template("patient/appointments.html", appointments=appts)


@patient_bp.route("/appointments/<int:appt_id>/cancel", methods=["POST"])
@login_required
@role_required("patient")
def cancel_appointment(appt_id):
    profile = _own_profile_or_403()
    appt = Appointment.query.get_or_404(appt_id)
    if appt.patient_id != profile.id:
        abort(403)
    appt.status = "cancelled"
    db.session.commit()
    log_action(current_user.id, "CANCEL_APPOINTMENT", "appointment", appt.id)
    flash("Appointment cancelled.", "info")
    return redirect(url_for("patient.appointments"))


@patient_bp.route("/vitals/log", methods=["GET", "POST"])
@login_required
@role_required("patient")
def log_vitals():
    profile = _own_profile_or_403()
    form = SelfVitalsForm()
    if form.validate_on_submit():
        v = VitalReading(patient_id=profile.id, recorded_by=current_user.id)
        populate_model(form, v)
        flags_csv, triggered = evaluate_vitals(v)
        v.risk_flags = flags_csv
        db.session.add(v)
        db.session.commit()
        log_action(current_user.id, "LOG_VITALS", "vital_reading", v.id, details=flags_csv)
        if triggered:
            flash(f"Vitals logged. Risk flags detected: {', '.join(t[2] for t in triggered)}", "warning")
        else:
            flash("Vitals logged. All within normal range.", "success")
        return redirect(url_for("patient.dashboard"))
    return render_template("patient/log_vitals.html", form=form)


@patient_bp.route("/health-check", methods=["GET", "POST"])
@login_required
@role_required("patient")
def health_check():
    """Self-check: enter (or reuse) a set of readings and get a plain
    good / watch / needs-attention verdict for each one, plus BMI."""
    profile = _own_profile_or_403()
    form = SelfCheckForm()

    reading = None
    height_cm = profile.height_cm
    saved = False

    if form.validate_on_submit():
        # Assess whatever was typed, without requiring it be saved.
        reading = VitalReading(
            patient_id=profile.id,
            systolic_bp=form.systolic_bp.data, diastolic_bp=form.diastolic_bp.data,
            heart_rate=form.heart_rate.data, blood_sugar=form.blood_sugar.data,
            temperature=form.temperature.data, spo2=form.spo2.data,
            weight_kg=form.weight_kg.data,
        )
        if form.height_cm.data:
            height_cm = form.height_cm.data
            # Remember it so BMI works next time without re-entering.
            if profile.height_cm != height_cm:
                profile.height_cm = height_cm

        if form.save_reading.data:
            flags, _ = evaluate_vitals(reading)
            reading.risk_flags = flags
            reading.recorded_by = current_user.id
            db.session.add(reading)
            saved = True

        db.session.commit()
        log_action(current_user.id, "SELF_CHECK", "patient_profile", profile.id,
                   details="saved" if saved else "not saved")
    else:
        # First visit: check their most recent saved reading, if any.
        reading = (VitalReading.query.filter_by(patient_id=profile.id)
                   .order_by(VitalReading.recorded_at.desc()).first())
        if reading:
            form.systolic_bp.data = reading.systolic_bp
            form.diastolic_bp.data = reading.diastolic_bp
            form.heart_rate.data = reading.heart_rate
            form.blood_sugar.data = reading.blood_sugar
            form.temperature.data = reading.temperature
            form.spo2.data = reading.spo2
            form.weight_kg.data = reading.weight_kg
        form.height_cm.data = height_cm

    results = assess_reading(reading, height_cm) if reading else []
    summary = overall(results)

    return render_template("patient/health_check.html", form=form, results=results,
                            summary=summary, saved=saved, height_cm=height_cm,
                            has_reading=bool(reading))


@patient_bp.route("/health-card")
@login_required
@role_required("patient")
def health_card():
    profile = _own_profile_or_403()
    payload = f"AMAR-EHR|patient_uid={profile.public_uid}|name={current_user.full_name}|blood={profile.blood_group or 'N/A'}"
    qr_data_uri = generate_qr_data_uri(payload)
    log_action(current_user.id, "VIEW_HEALTH_CARD", "patient_profile", profile.id)
    return render_template("patient/health_card.html", profile=profile, qr_data_uri=qr_data_uri)


@patient_bp.route("/records")
@login_required
@role_required("patient")
def records():
    profile = _own_profile_or_403()
    query = MedicalRecord.query.filter_by(patient_id=profile.id)
    search = request.args.get("q", "").strip()
    records_list = query.order_by(MedicalRecord.created_at.desc()).all()
    if search:
        records_list = [r for r in records_list if search.lower() in r.searchable_text().lower()]
    log_action(current_user.id, "VIEW_RECORDS", "patient_profile", profile.id)
    return render_template("patient/records.html", records=records_list, search=search)


@patient_bp.route("/records/export", methods=["GET", "POST"])
@login_required
@role_required("patient")
def export_records():
    profile = _own_profile_or_403()
    form = ExportPasswordForm()
    if form.validate_on_submit():
        records = MedicalRecord.query.filter_by(patient_id=profile.id).order_by(MedicalRecord.created_at.asc()).all()
        vitals = VitalReading.query.filter_by(patient_id=profile.id).order_by(VitalReading.recorded_at.asc()).all()
        prescriptions = (Prescription.query.join(MedicalRecord)
                          .filter(MedicalRecord.patient_id == profile.id).all())
        pdf_bytes = generate_records_export_pdf(current_user, profile, records, vitals, prescriptions)
        encrypted = encrypt_pdf_bytes(pdf_bytes, form.password.data)
        log_action(current_user.id, "EXPORT_PDF", "patient_profile", profile.id,
                   details="encrypted records export")
        return send_file(io.BytesIO(encrypted), mimetype="application/pdf", as_attachment=True,
                          download_name=f"amar_ehr_records_{profile.public_uid[:8]}.pdf")
    return render_template("patient/export_records.html", form=form)
