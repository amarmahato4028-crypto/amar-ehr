from flask_wtf import FlaskForm
from wtforms import (StringField, SelectField, DateField, TextAreaField, DateTimeField,
                     SubmitField, IntegerField, FloatField, PasswordField, HiddenField,
                     BooleanField)
from wtforms.validators import DataRequired, Optional, Length, NumberRange


class ProfileForm(FlaskForm):
    date_of_birth = DateField("Date of birth", validators=[Optional()])
    gender = SelectField("Gender", choices=[("", "Prefer not to say"), ("female", "Female"),
                                             ("male", "Male"), ("other", "Other")],
                          validators=[Optional()])
    blood_group = SelectField("Blood group", choices=[("", "I don't know")] + [(g, g) for g in
                               ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"]],
                              validators=[Optional()], description="Shown on your health card")
    height_cm = FloatField("Height", validators=[Optional(), NumberRange(min=50, max=260,
                            message="Please enter your height in centimetres, e.g. 170.")],
                           description="In centimetres — we use this to work out your BMI")
    address = TextAreaField("Home address", validators=[Optional(), Length(max=500)])
    emergency_contact = StringField("Emergency contact", validators=[Optional(), Length(max=255)],
                                    description="Name and phone number of someone we can call")
    known_allergies = TextAreaField("Allergies", validators=[Optional(), Length(max=500)],
                                    description="Medicines or foods you react badly to. "
                                                "Leave blank if none.")
    chronic_conditions = TextAreaField("Ongoing conditions", validators=[Optional(), Length(max=500)],
                                       description="Anything you're managing long-term, "
                                                   "e.g. asthma or diabetes")
    submit = SubmitField("Save my details")


class BookAppointmentForm(FlaskForm):
    doctor_id = SelectField("Doctor", coerce=int, validators=[DataRequired()])
    scheduled_at = DateTimeField("Date & Time", format="%Y-%m-%dT%H:%M", validators=[DataRequired()])
    # Populated by JS with Date.getTimezoneOffset() so the local wall-clock
    # time the user picked can be converted to UTC for storage. Defaults to
    # 0 (treat as UTC) if JS is unavailable.
    tz_offset = HiddenField(default="0")
    reason = StringField("What's it about?", validators=[Optional(), Length(max=255)],
                          description="A short note helps your doctor prepare, "
                                      "e.g. 'persistent cough'")
    submit = SubmitField("Confirm booking")


class SelfVitalsForm(FlaskForm):
    """Labels are deliberately plain — a patient shouldn't need to know what
    'systolic' or 'SpO2' means to record a reading."""
    systolic_bp = IntegerField("Blood pressure — top number", validators=[Optional()],
                               description="The higher number, e.g. 120")
    diastolic_bp = IntegerField("Blood pressure — bottom number", validators=[Optional()],
                                description="The lower number, e.g. 80")
    heart_rate = IntegerField("Heart rate", validators=[Optional()],
                              description="Beats per minute, e.g. 72")
    blood_sugar = FloatField("Blood sugar", validators=[Optional()],
                             description="From a glucose meter, in mg/dL, e.g. 95")
    temperature = FloatField("Body temperature", validators=[Optional()],
                             description="In °C, e.g. 36.6")
    spo2 = IntegerField("Oxygen level", validators=[Optional()],
                        description="From a fingertip pulse oximeter, e.g. 98")
    weight_kg = FloatField("Weight", validators=[Optional()],
                           description="In kilograms, e.g. 70")
    submit = SubmitField("Save reading")


class SelfCheckForm(FlaskForm):
    """Same readings as the vitals form, plus height for BMI. Everything is
    optional — the check reports on whatever you fill in."""
    systolic_bp = IntegerField("Blood pressure — top number", validators=[Optional(),
                               NumberRange(min=50, max=260, message="Please enter a value between 50 and 260.")],
                               description="e.g. 120")
    diastolic_bp = IntegerField("Blood pressure — bottom number", validators=[Optional(),
                                NumberRange(min=30, max=180, message="Please enter a value between 30 and 180.")],
                                description="e.g. 80")
    heart_rate = IntegerField("Heart rate", validators=[Optional(),
                              NumberRange(min=20, max=250, message="Please enter a value between 20 and 250.")],
                              description="Beats per minute, e.g. 72")
    spo2 = IntegerField("Oxygen level", validators=[Optional(),
                        NumberRange(min=50, max=100, message="Please enter a value between 50 and 100.")],
                        description="From a fingertip oximeter, e.g. 98")
    blood_sugar = FloatField("Blood sugar", validators=[Optional(),
                             NumberRange(min=20, max=700, message="Please enter a value between 20 and 700.")],
                             description="From a glucose meter, in mg/dL, e.g. 95")
    temperature = FloatField("Body temperature", validators=[Optional(),
                             NumberRange(min=30, max=45, message="Please enter a value between 30 and 45.")],
                             description="In °C, e.g. 36.6")
    weight_kg = FloatField("Weight", validators=[Optional(),
                           NumberRange(min=10, max=400, message="Please enter a value between 10 and 400.")],
                           description="In kilograms — needed for BMI")
    height_cm = FloatField("Height", validators=[Optional(),
                           NumberRange(min=50, max=260, message="Please enter your height in centimetres.")],
                           description="In centimetres — needed for BMI")
    save_reading = BooleanField("Also save this to my records", default=True)
    submit = SubmitField("Check my readings")


class ExportPasswordForm(FlaskForm):
    password = PasswordField("Choose a password for the file",
                              validators=[DataRequired(), Length(min=6)],
                              description="You'll need to type this to open the PDF. "
                                          "At least 6 characters.")
    submit = SubmitField("Download my records")
