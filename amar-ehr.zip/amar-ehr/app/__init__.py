import os
from flask import Flask, render_template
from app.config import config_by_name
from app.extensions import db, login_manager, csrf, limiter, migrate, mail


def create_app(config_name=None):
    config_name = config_name or os.environ.get("FLASK_ENV", "production")
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_by_name.get(config_name, config_by_name["production"]))

    os.makedirs(app.instance_path, exist_ok=True)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)
    migrate.init_app(app, db)
    mail.init_app(app)

    from app.models.user import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Blueprints
    from app.auth.routes import auth_bp
    from app.patient.routes import patient_bp
    from app.doctor.routes import doctor_bp
    from app.admin.routes import admin_bp
    from app.records.routes import records_bp
    from app.api.routes import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(patient_bp, url_prefix="/patient")
    app.register_blueprint(doctor_bp, url_prefix="/doctor")
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(records_bp, url_prefix="/records")
    app.register_blueprint(api_bp, url_prefix="/api")

    from app.main_routes import main_bp
    app.register_blueprint(main_bp)

    register_error_handlers(app)
    register_security_headers(app)
    register_2fa_gate(app)
    register_template_filters(app)

    return app


def register_template_filters(app):
    """`localdt` renders a stored naive-UTC datetime as a <time> element that
    static/js/localtime.js rewrites into the viewer's own timezone. Without
    this, every timestamp in the UI would read as UTC.

    Default format is deliberately human ("Sat, 15 Aug · 2:30 PM") rather
    than ISO — patients shouldn't have to parse 2026-08-15 14:30.
    """
    from markupsafe import Markup, escape
    from app.utils.timeutils import to_iso_z
    from app.utils import display

    FRIENDLY = "%a, %d %b · %I:%M %p"

    @app.template_filter("localdt")
    def localdt(dt, fmt=FRIENDLY):
        if dt is None:
            return "-"
        iso = to_iso_z(dt)
        fallback = dt.strftime(fmt).replace(" 0", " ") + " UTC"
        return Markup(
            f'<time class="js-localtime" datetime="{escape(iso)}" '
            f'data-fmt="{escape(fmt)}">{escape(fallback)}</time>'
        )

    display.register(app)

    @app.template_global("nav_active")
    def nav_active(*endpoints):
        """Highlights the current page in the navbar so users always know
        where they are."""
        from flask import request
        return "active" if request.endpoint in endpoints else ""


def register_2fa_gate(app):
    """Server-side enforcement that doctor/admin accounts cannot use the
    app until 2FA is enabled — matches the spec's 'enforce 2FA especially
    for doctor/admin accounts'. A redirect here is not just a UI nicety;
    every protected view stays unreachable for these roles until 2FA is on."""
    from flask import redirect, url_for, request
    from flask_login import current_user

    EXEMPT_ENDPOINTS = {"auth.setup_2fa", "auth.logout", "static"}

    @app.before_request
    def enforce_2fa_for_privileged_roles():
        if not current_user.is_authenticated:
            return None
        if request.endpoint in EXEMPT_ENDPOINTS:
            return None
        if current_user.role in ("doctor", "admin") and not current_user.two_fa_enabled:
            return redirect(url_for("auth.setup_2fa"))
        return None


def register_error_handlers(app):
    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(413)
    def payload_too_large(e):
        # Flask aborts with 413 when an upload exceeds MAX_CONTENT_LENGTH,
        # before any view code runs — without this handler the user would
        # get a bare server error page instead of an explanation.
        return render_template("errors/413.html",
                               max_mb=app.config["MAX_CONTENT_LENGTH"] // (1024 * 1024)), 413

    @app.errorhandler(429)
    def rate_limited(e):
        return render_template("errors/429.html"), 429

    @app.errorhandler(500)
    def server_error(e):
        return render_template("errors/500.html"), 500


def register_security_headers(app):
    @app.after_request
    def set_secure_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; "
            "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "script-src 'self' https://cdn.jsdelivr.net;",
        )
        if app.config.get("SESSION_COOKIE_SECURE"):
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        return response
