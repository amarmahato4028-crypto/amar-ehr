"""Form helpers."""

# Fields that exist for the form's own machinery and must never be written
# onto a database model. WTForms' populate_obj() copies *every* field,
# which would otherwise set `model.submit` and `model.csrf_token` as stray
# instance attributes.
_NON_DATA_FIELDS = {"submit", "csrf_token", "tz_offset"}


def populate_model(form, model, exclude=()):
    """Like form.populate_obj(model), but skips submit/CSRF/helper fields.

    Also normalises empty-string selects to None so an unanswered dropdown
    stores NULL rather than "".
    """
    skip = _NON_DATA_FIELDS | set(exclude)
    for name, field in form._fields.items():
        if name in skip:
            continue
        value = field.data
        if value == "":
            value = None
        setattr(model, name, value)
    return model
