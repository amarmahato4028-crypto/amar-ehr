"""
Plain-language presentation helpers.

The database stores compact codes (HIGH_BP, no_show) because they're stable
and easy to query. Users should never see them. Everything here turns a
stored code into something a non-technical person understands, and it all
gets registered as Jinja filters so templates can't accidentally leak a raw
code to the screen.
"""

# Risk flags -> what a patient would actually call it.
RISK_LABELS = {
    "HIGH_BP": "High blood pressure",
    "LOW_BP": "Low blood pressure",
    "HIGH_SUGAR": "High blood sugar",
    "LOW_SUGAR": "Low blood sugar",
    "HIGH_HEART_RATE": "Fast heart rate",
    "LOW_HEART_RATE": "Slow heart rate",
    "LOW_SPO2": "Low oxygen level",
    "FEVER": "Fever",
}

# How serious, for colour-coding. high = needs attention soon.
RISK_SEVERITY = {
    "HIGH_BP": "high", "LOW_BP": "medium",
    "HIGH_SUGAR": "high", "LOW_SUGAR": "high",
    "HIGH_HEART_RATE": "medium", "LOW_HEART_RATE": "medium",
    "LOW_SPO2": "high", "FEVER": "medium",
}

APPOINTMENT_STATUS_LABELS = {
    "scheduled": "Upcoming",
    "completed": "Completed",
    "cancelled": "Cancelled",
    "no_show": "Missed",
}

APPOINTMENT_STATUS_COLOURS = {
    "scheduled": "primary",
    "completed": "success",
    "cancelled": "secondary",
    "no_show": "warning",
}

# Audit actions -> a sentence an administrator can read at a glance.
ACTION_LABELS = {
    "LOGIN_SUCCESS": "Signed in",
    "LOGIN_FAILED": "Failed sign-in attempt",
    "LOGIN_BLOCKED_LOCKED": "Blocked — account locked",
    "LOGIN_BLOCKED_DEACTIVATED": "Blocked — account deactivated",
    "LOGOUT": "Signed out",
    "REGISTER": "Created an account",
    "2FA_ENABLED": "Turned on 2-step verification",
    "2FA_DISABLED": "Turned off 2-step verification",
    "LOGIN_2FA_FAILED": "Wrong verification code",
    "VIEW_DASHBOARD": "Opened dashboard",
    "VIEW_RECORDS": "Viewed medical records",
    "VIEW_PATIENT_RECORD": "Opened a patient's record",
    "VIEW_PATIENT_LIST": "Viewed patient list",
    "VIEW_HEALTH_CARD": "Viewed health card",
    "VIEW_LAB_REPORTS": "Viewed lab reports",
    "VIEW_ADMIN_DASHBOARD": "Opened admin dashboard",
    "CREATE_RECORD": "Added a medical record",
    "CREATE_PRESCRIPTION": "Wrote a prescription",
    "RECORD_VITALS": "Recorded health readings",
    "LOG_VITALS": "Logged health readings",
    "BOOK_APPOINTMENT": "Booked an appointment",
    "CANCEL_APPOINTMENT": "Cancelled an appointment",
    "UPDATE_APPOINTMENT_STATUS": "Updated an appointment",
    "UPDATE_PROFILE": "Updated profile",
    "UPLOAD_LAB_REPORT": "Uploaded a lab report",
    "DOWNLOAD_LAB_REPORT": "Downloaded a lab report",
    "DOWNLOAD_PRESCRIPTION": "Downloaded a prescription",
    "EXPORT_PDF": "Downloaded their records",
    "SEARCH_RECORDS": "Searched records",
    "ACCESS_DENIED": "Was denied access",
    "TOGGLE_USER_ACTIVE": "Changed account status",
    "UNLOCK_USER": "Unlocked an account",
    "VERIFY_AUDIT_CHAIN": "Checked audit-log integrity",
    "CHATBOT_QUERY": "Asked the health assistant",
}

ROLE_LABELS = {"patient": "Patient", "doctor": "Doctor", "admin": "Administrator"}


def risk_labels(flags_csv):
    """'HIGH_BP,FEVER' -> ['High blood pressure', 'Fever']"""
    if not flags_csv:
        return []
    return [RISK_LABELS.get(c.strip(), c.strip().replace("_", " ").title())
            for c in flags_csv.split(",") if c.strip()]


def risk_label_text(flags_csv):
    return ", ".join(risk_labels(flags_csv))


def worst_severity(flags_csv):
    if not flags_csv:
        return None
    sevs = [RISK_SEVERITY.get(c.strip(), "medium") for c in flags_csv.split(",") if c.strip()]
    return "high" if "high" in sevs else ("medium" if sevs else None)


def status_label(status):
    return APPOINTMENT_STATUS_LABELS.get(status, (status or "").replace("_", " ").capitalize())


def status_colour(status):
    return APPOINTMENT_STATUS_COLOURS.get(status, "secondary")


def action_label(action):
    return ACTION_LABELS.get(action, (action or "").replace("_", " ").capitalize())


def role_label(role):
    return ROLE_LABELS.get(role, (role or "").capitalize())


def detail_text(details):
    """Audit `details` is free-form and sometimes holds raw risk codes
    (written by the vitals routes). Humanise those so the activity log
    doesn't show HIGH_BP to an administrator."""
    if not details:
        return ""
    parts = [p.strip() for p in details.split(",") if p.strip()]
    if parts and all(p in RISK_LABELS for p in parts):
        return ", ".join(RISK_LABELS[p] for p in parts)
    if details.startswith("status="):
        return "Marked as " + status_label(details.split("=", 1)[1])
    return details


def register(app):
    app.add_template_filter(risk_labels, "risk_labels")
    app.add_template_filter(risk_label_text, "risk_text")
    app.add_template_filter(worst_severity, "risk_severity")
    app.add_template_filter(status_label, "status_label")
    app.add_template_filter(status_colour, "status_colour")
    app.add_template_filter(action_label, "action_label")
    app.add_template_filter(role_label, "role_label")
    app.add_template_filter(detail_text, "detail_text")
