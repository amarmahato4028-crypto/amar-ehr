"""
Rule-based vitals anomaly / risk flagging.

Deliberately simple and explainable (no ML) — every threshold is a named
clinical rule of thumb so the flags can be defended in a capstone demo/viva.
Returns a list of (flag_code, severity, message) tuples.
"""

RULES = []


def rule(code, severity):
    def decorator(fn):
        RULES.append((code, severity, fn))
        return fn
    return decorator


@rule("HIGH_BP", "high")
def _high_bp(v):
    return v.systolic_bp is not None and v.diastolic_bp is not None and (
        v.systolic_bp >= 140 or v.diastolic_bp >= 90
    )


@rule("LOW_BP", "medium")
def _low_bp(v):
    return v.systolic_bp is not None and v.diastolic_bp is not None and (
        v.systolic_bp < 90 or v.diastolic_bp < 60
    )


@rule("HIGH_SUGAR", "high")
def _high_sugar(v):
    return v.blood_sugar is not None and v.blood_sugar >= 180


@rule("LOW_SUGAR", "high")
def _low_sugar(v):
    return v.blood_sugar is not None and v.blood_sugar < 70


@rule("HIGH_HEART_RATE", "medium")
def _high_hr(v):
    return v.heart_rate is not None and v.heart_rate > 100


@rule("LOW_HEART_RATE", "medium")
def _low_hr(v):
    return v.heart_rate is not None and v.heart_rate < 60


@rule("LOW_SPO2", "high")
def _low_spo2(v):
    return v.spo2 is not None and v.spo2 < 92


@rule("FEVER", "medium")
def _fever(v):
    return v.temperature is not None and v.temperature >= 38.0


MESSAGES = {
    "HIGH_BP": "Elevated blood pressure (possible hypertension) — recommend clinical follow-up.",
    "LOW_BP": "Low blood pressure (possible hypotension).",
    "HIGH_SUGAR": "Elevated blood glucose (possible hyperglycemia).",
    "LOW_SUGAR": "Low blood glucose (possible hypoglycemia) — urgent attention advised.",
    "HIGH_HEART_RATE": "Elevated heart rate (tachycardia).",
    "LOW_HEART_RATE": "Low heart rate (bradycardia).",
    "LOW_SPO2": "Low oxygen saturation — urgent attention advised.",
    "FEVER": "Fever detected.",
}


def evaluate_vitals(vital_reading):
    """Returns (flags_csv, [(code, severity, message), ...])."""
    triggered = []
    for code, severity, fn in RULES:
        try:
            if fn(vital_reading):
                triggered.append((code, severity, MESSAGES[code]))
        except Exception:
            continue
    flags_csv = ",".join(code for code, _, _ in triggered)
    return flags_csv, triggered
