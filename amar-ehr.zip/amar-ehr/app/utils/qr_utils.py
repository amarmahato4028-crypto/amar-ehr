"""QR health card generation."""
import io
import base64
import qrcode


def generate_qr_png_bytes(data: str) -> bytes:
    img = qrcode.make(data, box_size=8, border=2)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def generate_qr_data_uri(data: str) -> str:
    png = generate_qr_png_bytes(data)
    b64 = base64.b64encode(png).decode()
    return f"data:image/png;base64,{b64}"
