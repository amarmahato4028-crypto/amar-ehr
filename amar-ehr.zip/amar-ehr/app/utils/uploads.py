import os
import uuid
from flask import current_app


def allowed_file(filename: str) -> bool:
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in current_app.config["ALLOWED_UPLOAD_EXTENSIONS"]


def safe_stored_name(original_filename: str) -> str:
    ext = original_filename.rsplit(".", 1)[1].lower()
    return f"{uuid.uuid4().hex}.{ext}.enc"


def upload_path(stored_filename: str) -> str:
    return os.path.join(current_app.config["UPLOAD_FOLDER"], stored_filename)
