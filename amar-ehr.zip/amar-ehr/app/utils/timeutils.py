"""
Time handling for Amar EHR.

Rule for the whole codebase: **every datetime stored in the database is
naive UTC.** Mixing timezone-aware and naive datetimes is the classic
source of "my appointment disappeared" bugs — on SQLite, SQLAlchemy binds
a DateTime as an ISO string, so an aware value serialises with a "+00:00"
suffix while a naive one does not, and comparing the two becomes a broken
string comparison.

Browsers submit `<input type="datetime-local">` as the user's *local wall
clock* with no offset attached. We capture the offset separately (a hidden
field populated by JS) and convert to UTC on the way in, then convert back
to local in the browser on the way out.
"""
from datetime import datetime, timezone, timedelta


def utcnow() -> datetime:
    """Current time as a naive UTC datetime (the storage format)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def local_to_utc(local_dt: datetime, offset_minutes) -> datetime:
    """Convert a naive local wall-clock datetime to naive UTC.

    `offset_minutes` is JavaScript's `Date.getTimezoneOffset()`, i.e.
    (UTC - local) in minutes: 240 for EDT, -330 for IST.
    """
    if local_dt is None:
        return None
    try:
        offset = int(offset_minutes)
    except (TypeError, ValueError):
        offset = 0
    # Guard against nonsense/hostile values (real offsets are -840..840).
    if not -840 <= offset <= 840:
        offset = 0
    return local_dt + timedelta(minutes=offset)


def to_iso_z(dt: datetime) -> str:
    """Render a stored naive-UTC datetime as an ISO-8601 Z string, which is
    what the client-side localiser expects."""
    if dt is None:
        return ""
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
