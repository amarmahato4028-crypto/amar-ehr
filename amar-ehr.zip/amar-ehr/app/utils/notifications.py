"""Email + SMS reminders. Both are best-effort/no-op-safe: if credentials
aren't configured (e.g. local demo), calls simply no-op instead of crashing
the request — MAIL_SUPPRESS_SEND defaults to true for that reason."""
from flask import current_app
from flask_mail import Message
from app.extensions import mail


def send_appointment_email(to_email, subject, body_text):
    try:
        msg = Message(subject=subject, recipients=[to_email], body=body_text)
        mail.send(msg)
        return True
    except Exception as e:
        current_app.logger.warning(f"Email send failed: {e}")
        return False


def send_sms_reminder(to_phone, body_text):
    sid = current_app.config.get("TWILIO_ACCOUNT_SID")
    token = current_app.config.get("TWILIO_AUTH_TOKEN")
    from_number = current_app.config.get("TWILIO_FROM_NUMBER")
    if not (sid and token and from_number and to_phone):
        current_app.logger.info("SMS not configured/skipped (Twilio credentials missing).")
        return False
    try:
        from twilio.rest import Client
        client = Client(sid, token)
        client.messages.create(body=body_text, from_=from_number, to=to_phone)
        return True
    except Exception as e:
        current_app.logger.warning(f"SMS send failed: {e}")
        return False


def appointment_reminder_text(appointment, patient_name, doctor_name):
    when = appointment.scheduled_at.strftime("%A, %d %B %Y at %I:%M %p")
    return (f"Hi {patient_name}, this is a reminder of your appointment with "
            f"Dr. {doctor_name} on {when}. — Amar EHR")
