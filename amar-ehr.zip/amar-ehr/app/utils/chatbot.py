"""
Rule-based symptom-checker chatbot.

A small decision tree over keyword matches. This is explicitly NOT a
diagnostic tool — every response carries a disclaimer — but it demonstrates
a working intelligence layer without depending on an external LLM/API,
which keeps the capstone fully self-contained and free to run.
"""
import re

DISCLAIMER = ("This is an automated, rule-based assistant for general guidance only. "
              "It is not a medical diagnosis. Seek emergency care for severe symptoms.")

EMERGENCY_KEYWORDS = [
    "chest pain", "can't breathe", "cannot breathe", "difficulty breathing",
    "severe bleeding", "unconscious", "stroke", "suicidal", "seizure",
]

RULES = [
    (r"\bfever\b|\btemperature\b|\bchills\b",
     "A fever can indicate infection. Stay hydrated, rest, and monitor your temperature. "
     "If it stays above 39°C (102°F) for more than 2 days, or you have a rash or stiff neck, book an appointment."),
    (r"\bheadache\b|\bmigraine\b",
     "For headaches: rest in a dark quiet room, stay hydrated, and consider an over-the-counter "
     "pain reliever if you have no contraindications. Sudden, severe ('worst of your life') headaches need urgent care."),
    (r"\bcough\b|\bsore throat\b|\bcold\b|\bflu\b",
     "Common cold/flu symptoms usually resolve in 7-10 days with rest and fluids. "
     "See a doctor if symptoms worsen after a week, or you develop shortness of breath."),
    (r"\bblood pressure\b|\bbp\b|\bhypertension\b",
     "High blood pressure is often symptomless — regular monitoring matters. "
     "Log your readings in your dashboard so trends are visible to your doctor."),
    (r"\bsugar\b|\bdiabetes\b|\bglucose\b",
     "Blood sugar concerns should be tracked over time. Log readings regularly and discuss "
     "any values consistently above 180 mg/dL or below 70 mg/dL with your doctor."),
    (r"\brash\b|\bskin\b|\bitch",
     "Skin issues can have many causes. Note when it started, whether it's spreading, and "
     "any new products/medications, then book a dermatology-relevant appointment."),
    (r"\bstomach\b|\bnausea\b|\bvomit|\bdiarrhea\b",
     "For mild stomach upset: stay hydrated with small sips of water/oral rehydration solution "
     "and eat bland food. See a doctor if symptoms persist beyond 48 hours or you see blood."),
    (r"\bappointment\b|\bbook\b|\bschedule\b",
     "You can book an appointment from your Patient Dashboard under 'Book Appointment' — "
     "pick a doctor by specialization and an available time slot."),
    (r"\bprescription\b|\bmedication\b|\bmedicine\b",
     "Your prescriptions are listed under Medical Records, and each one can be downloaded as a PDF."),
]


def get_response(message: str) -> dict:
    text = (message or "").lower()

    for kw in EMERGENCY_KEYWORDS:
        if kw in text:
            return {
                "reply": ("This may be a medical emergency. Please call your local emergency "
                          "number or go to the nearest emergency room immediately."),
                "urgent": True,
                "disclaimer": DISCLAIMER,
            }

    for pattern, reply in RULES:
        if re.search(pattern, text):
            return {"reply": reply, "urgent": False, "disclaimer": DISCLAIMER}

    return {
        "reply": ("I can help with general guidance on common symptoms (fever, headache, cough, "
                  "blood pressure, blood sugar, skin issues, stomach issues) or with booking an "
                  "appointment. Could you describe your symptom in a bit more detail?"),
        "urgent": False,
        "disclaimer": DISCLAIMER,
    }
