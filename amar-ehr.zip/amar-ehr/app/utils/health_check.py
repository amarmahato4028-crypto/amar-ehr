"""
Self-check: turns a raw reading into a plain-language verdict.

Where `anomaly.py` answers "should this raise an alert?" (a single
clinically urgent threshold), this module answers "how am I doing?" — it
places each value on a graded scale and explains it in words a patient
understands.

Every band carries a `tone` the UI colours by:
    good     — in the healthy range
    caution  — outside ideal, worth watching
    bad      — needs medical attention

None of this is a diagnosis, and every screen that uses it says so.
Thresholds follow widely published adult reference ranges (AHA for blood
pressure, WHO for BMI); they are general guidance, not personalised
medical advice, and don't apply to children or pregnancy.
"""

TONE_GOOD = "good"
TONE_CAUTION = "caution"
TONE_BAD = "bad"

TONE_LABELS = {TONE_GOOD: "Good", TONE_CAUTION: "Watch", TONE_BAD: "Needs attention"}


class Result:
    """One metric's verdict."""

    def __init__(self, key, title, value_text, band, tone, explanation,
                 advice="", scale=None, position=None, unit=""):
        self.key = key
        self.title = title
        self.value_text = value_text
        self.band = band                 # e.g. "Normal", "Slightly high"
        self.tone = tone
        self.tone_label = TONE_LABELS[tone]
        self.explanation = explanation
        self.advice = advice
        self.scale = scale or []         # segments for the visual bar
        self.position = position         # 0-100, where the marker sits
        self.unit = unit

    @property
    def is_good(self):
        return self.tone == TONE_GOOD


def _position(value, low, high):
    """Where a value sits on a bar running low..high, clamped to 0-100."""
    if value is None:
        return None
    span = high - low
    if span <= 0:
        return 0
    return max(0.0, min(100.0, (value - low) / span * 100.0))


def _seg(label, tone, width):
    return {"label": label, "tone": tone, "width": width}


# --------------------------------------------------------------- blood pressure
BP_SCALE = [
    _seg("Low", TONE_CAUTION, 18),
    _seg("Normal", TONE_GOOD, 22),
    _seg("Raised", TONE_CAUTION, 20),
    _seg("High", TONE_BAD, 40),
]


def assess_blood_pressure(systolic, diastolic):
    if systolic is None or diastolic is None:
        return None

    if systolic >= 180 or diastolic >= 120:
        band, tone = "Very high", TONE_BAD
        explanation = "This is well above the healthy range."
        advice = "Please seek medical care promptly, especially with chest pain, breathlessness or vision changes."
    elif systolic >= 140 or diastolic >= 90:
        band, tone = "High", TONE_BAD
        explanation = "This is in the high blood pressure range."
        advice = "Worth discussing with your doctor — take a few readings over the coming days first."
    elif systolic >= 130 or diastolic >= 80:
        band, tone = "Slightly high", TONE_CAUTION
        explanation = "A little above the ideal range."
        advice = "Keep an eye on it. Less salt, regular movement and good sleep all help."
    elif systolic >= 120:
        band, tone = "Raised", TONE_CAUTION
        explanation = "Just above ideal, but not yet high blood pressure."
        advice = "Nothing to worry about — keep logging it so you can see the trend."
    elif systolic < 90 or diastolic < 60:
        band, tone = "Low", TONE_CAUTION
        explanation = "This is on the low side."
        advice = "If you feel dizzy, faint or unusually tired, mention it to your doctor."
    else:
        band, tone = "Normal", TONE_GOOD
        explanation = "Your blood pressure is in the healthy range."
        advice = "Nicely done — keep doing what you're doing."

    return Result(
        key="blood_pressure", title="Blood pressure",
        value_text=f"{systolic}/{diastolic}", unit="mmHg",
        band=band, tone=tone, explanation=explanation, advice=advice,
        scale=BP_SCALE, position=_position(systolic, 80, 180),
    )


# ------------------------------------------------------------------- oxygen
SPO2_SCALE = [
    _seg("Low", TONE_BAD, 40),
    _seg("Slightly low", TONE_CAUTION, 20),
    _seg("Normal", TONE_GOOD, 40),
]


def assess_spo2(spo2):
    if spo2 is None:
        return None

    if spo2 >= 95:
        band, tone = "Normal", TONE_GOOD
        explanation = "Your blood is carrying oxygen well."
        advice = "No action needed."
    elif spo2 >= 91:
        band, tone = "Slightly low", TONE_CAUTION
        explanation = "A little below the usual range."
        advice = "Re-check with warm hands and still fingers — cold hands often read low. If it stays here, contact your doctor."
    else:
        band, tone = "Low", TONE_BAD
        explanation = "This is below the safe range."
        advice = "Seek medical help now, particularly if you're short of breath."

    return Result(
        key="spo2", title="Oxygen level", value_text=str(spo2), unit="%",
        band=band, tone=tone, explanation=explanation, advice=advice,
        scale=SPO2_SCALE, position=_position(spo2, 85, 100),
    )


# --------------------------------------------------------------- heart rate
HR_SCALE = [
    _seg("Low", TONE_CAUTION, 20),
    _seg("Normal", TONE_GOOD, 40),
    _seg("Raised", TONE_CAUTION, 20),
    _seg("High", TONE_BAD, 20),
]


def assess_heart_rate(bpm):
    if bpm is None:
        return None

    if bpm > 120:
        band, tone = "High", TONE_BAD
        explanation = "Your heart is beating faster than expected at rest."
        advice = "If you've just exercised this is normal. At rest, and with dizziness or chest discomfort, seek care."
    elif bpm > 100:
        band, tone = "Slightly high", TONE_CAUTION
        explanation = "A bit above the usual resting range."
        advice = "Rest for five minutes and take it again — caffeine, stress and heat all push this up."
    elif bpm < 50:
        band, tone = "Low", TONE_BAD
        explanation = "This is below the usual resting range."
        advice = "Common in very fit people. If you feel faint or unusually tired, speak to your doctor."
    elif bpm < 60:
        band, tone = "Slightly low", TONE_CAUTION
        explanation = "Slightly below the typical range, which is often perfectly healthy."
        advice = "Usually nothing to worry about, especially if you're active."
    else:
        band, tone = "Normal", TONE_GOOD
        explanation = "A healthy resting heart rate."
        advice = "No action needed."

    return Result(
        key="heart_rate", title="Heart rate", value_text=str(bpm), unit="bpm",
        band=band, tone=tone, explanation=explanation, advice=advice,
        scale=HR_SCALE, position=_position(bpm, 40, 140),
    )


# -------------------------------------------------------------- blood sugar
SUGAR_SCALE = [
    _seg("Low", TONE_BAD, 15),
    _seg("Normal", TONE_GOOD, 25),
    _seg("Raised", TONE_CAUTION, 25),
    _seg("High", TONE_BAD, 35),
]


def assess_blood_sugar(mgdl):
    if mgdl is None:
        return None

    if mgdl < 70:
        band, tone = "Low", TONE_BAD
        explanation = "This is below the healthy range (hypoglycaemia)."
        advice = "Have a sugary drink or snack now, then re-check in 15 minutes."
    elif mgdl <= 99:
        band, tone = "Normal", TONE_GOOD
        explanation = "Your blood sugar is in the healthy range."
        advice = "No action needed."
    elif mgdl <= 125:
        band, tone = "Slightly raised", TONE_CAUTION
        explanation = "Above ideal. If this was a fasting reading, it's in the pre-diabetes range."
        advice = "Worth mentioning at your next appointment, especially if it keeps reading here."
    elif mgdl < 180:
        band, tone = "High", TONE_CAUTION
        explanation = "Higher than the healthy range."
        advice = "Note whether you'd eaten recently, and discuss the pattern with your doctor."
    else:
        band, tone = "Very high", TONE_BAD
        explanation = "This is well above the healthy range."
        advice = "Contact your doctor. Seek urgent care if you also feel confused, very thirsty or unusually drowsy."

    return Result(
        key="blood_sugar", title="Blood sugar", value_text=f"{mgdl:g}", unit="mg/dL",
        band=band, tone=tone, explanation=explanation, advice=advice,
        scale=SUGAR_SCALE, position=_position(mgdl, 50, 250),
    )


# ------------------------------------------------------------- temperature
TEMP_SCALE = [
    _seg("Low", TONE_CAUTION, 25),
    _seg("Normal", TONE_GOOD, 30),
    _seg("Raised", TONE_CAUTION, 20),
    _seg("Fever", TONE_BAD, 25),
]


def assess_temperature(celsius):
    if celsius is None:
        return None

    if celsius >= 39.5:
        band, tone = "High fever", TONE_BAD
        explanation = "This is a high temperature."
        advice = "Seek medical advice, particularly with a stiff neck, rash, confusion or breathing trouble."
    elif celsius >= 38.0:
        band, tone = "Fever", TONE_BAD
        explanation = "You have a fever."
        advice = "Rest and drink fluids. See a doctor if it lasts more than three days or climbs higher."
    elif celsius >= 37.5:
        band, tone = "Slightly raised", TONE_CAUTION
        explanation = "A little above normal — this can be quite ordinary."
        advice = "Re-check in a few hours. Recent activity or a warm room can raise it."
    elif celsius < 35.0:
        band, tone = "Low", TONE_BAD
        explanation = "This is below the normal range."
        advice = "Warm up and re-check. If it stays this low, seek medical advice."
    elif celsius < 36.1:
        band, tone = "Slightly low", TONE_CAUTION
        explanation = "Slightly below the typical range."
        advice = "Often normal, especially first thing in the morning."
    else:
        band, tone = "Normal", TONE_GOOD
        explanation = "Your temperature is normal."
        advice = "No action needed."

    return Result(
        key="temperature", title="Temperature", value_text=f"{celsius:g}", unit="°C",
        band=band, tone=tone, explanation=explanation, advice=advice,
        scale=TEMP_SCALE, position=_position(celsius, 34.0, 40.0),
    )


# --------------------------------------------------------------------- BMI
BMI_SCALE = [
    _seg("Under", TONE_CAUTION, 20),
    _seg("Healthy", TONE_GOOD, 27),
    _seg("Over", TONE_CAUTION, 20),
    _seg("Obese", TONE_BAD, 33),
]


def compute_bmi(weight_kg, height_cm):
    """BMI = kg / m². Returns None unless both values are sensible."""
    if not weight_kg or not height_cm:
        return None
    if weight_kg <= 0 or height_cm <= 0:
        return None
    # Guard against someone entering height in metres or a typo.
    if not (50 <= height_cm <= 260) or not (10 <= weight_kg <= 400):
        return None
    metres = height_cm / 100.0
    return round(weight_kg / (metres * metres), 1)


def assess_bmi(bmi):
    if bmi is None:
        return None

    if bmi < 16.0:
        band, tone = "Very underweight", TONE_BAD
        explanation = "This is well below the healthy range."
        advice = "Please speak to a doctor about safe ways to gain weight."
    elif bmi < 18.5:
        band, tone = "Underweight", TONE_CAUTION
        explanation = "A little below the healthy range."
        advice = "A doctor or dietitian can help if you'd like to gain weight steadily."
    elif bmi < 25.0:
        band, tone = "Healthy weight", TONE_GOOD
        explanation = "Your weight is in the healthy range for your height."
        advice = "No action needed."
    elif bmi < 30.0:
        band, tone = "Overweight", TONE_CAUTION
        explanation = "Slightly above the healthy range for your height."
        advice = "Small, steady changes to food and movement make the biggest difference."
    else:
        band, tone = "Obese", TONE_BAD
        explanation = "Above the healthy range for your height."
        advice = "Worth planning next steps with your doctor — they can suggest realistic goals."

    return Result(
        key="bmi", title="BMI (weight for height)", value_text=f"{bmi:g}", unit="",
        band=band, tone=tone, explanation=explanation, advice=advice,
        scale=BMI_SCALE, position=_position(bmi, 14.0, 40.0),
    )


# ------------------------------------------------------------------ summary
def assess_reading(reading, height_cm=None):
    """Assess everything present on a VitalReading. Missing values are
    skipped rather than guessed at."""
    if reading is None:
        return []

    bmi = compute_bmi(getattr(reading, "weight_kg", None), height_cm)
    results = [
        assess_blood_pressure(getattr(reading, "systolic_bp", None),
                              getattr(reading, "diastolic_bp", None)),
        assess_heart_rate(getattr(reading, "heart_rate", None)),
        assess_spo2(getattr(reading, "spo2", None)),
        assess_blood_sugar(getattr(reading, "blood_sugar", None)),
        assess_temperature(getattr(reading, "temperature", None)),
        assess_bmi(bmi),
    ]
    return [r for r in results if r is not None]


def overall(results):
    """One headline verdict for a set of results."""
    if not results:
        return {"tone": None, "headline": "Nothing to check yet",
                "detail": "Add a reading and we'll tell you how it looks.",
                "counts": {TONE_GOOD: 0, TONE_CAUTION: 0, TONE_BAD: 0}}

    counts = {TONE_GOOD: 0, TONE_CAUTION: 0, TONE_BAD: 0}
    for r in results:
        counts[r.tone] += 1

    if counts[TONE_BAD]:
        return {"tone": TONE_BAD, "headline": "Some readings need attention",
                "detail": f"{counts[TONE_BAD]} of your {len(results)} readings are outside the safe range.",
                "counts": counts}
    if counts[TONE_CAUTION]:
        return {"tone": TONE_CAUTION, "headline": "Mostly fine, one or two to watch",
                "detail": f"{counts[TONE_GOOD]} of {len(results)} look good; the rest are worth keeping an eye on.",
                "counts": counts}
    return {"tone": TONE_GOOD, "headline": "Everything looks good",
            "detail": f"All {len(results)} of your readings are in the healthy range.",
            "counts": counts}
