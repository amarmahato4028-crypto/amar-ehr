from app.utils.timeutils import utcnow
from app.extensions import db


class AuditLog(db.Model):
    """Append-only audit trail. No update/delete route exists anywhere in
    the app for this table — not even for admins — and each row is chained
    to the previous one via SHA-256 (see security/hashchain.py) so tampering
    with historical rows is detectable."""
    __tablename__ = "audit_logs"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    action = db.Column(db.String(60), nullable=False)         # LOGIN, VIEW_RECORD, EXPORT_PDF, ...
    target_type = db.Column(db.String(60))                    # medical_record, appointment, user, ...
    target_id = db.Column(db.Integer, nullable=True)
    details = db.Column(db.String(500))
    ip_address = db.Column(db.String(64))
    timestamp = db.Column(db.DateTime, default=utcnow, index=True)

    # Both are unique: entry_hash identifies the row, and prev_hash being
    # unique is what keeps the chain *linear*. Under multiple gunicorn
    # workers two requests can read the same tail entry concurrently and
    # both try to chain onto it; the unique constraint makes the second
    # one fail so it can retry against the new tail (see decorators.py)
    # instead of silently forking the chain and tripping a false
    # "tampering detected" in verify_chain().
    prev_hash = db.Column(db.String(64), nullable=False, unique=True)
    entry_hash = db.Column(db.String(64), nullable=False, unique=True)

    user = db.relationship("User")
