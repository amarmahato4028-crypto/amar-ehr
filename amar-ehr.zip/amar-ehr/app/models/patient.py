from app.utils.timeutils import utcnow
import uuid
from app.extensions import db
from app.security.encryption import EncryptedString


class PatientProfile(db.Model):
    __tablename__ = "patient_profiles"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)

    # Public-safe identifier used in QR health card (never expose raw PK)
    public_uid = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))

    date_of_birth = db.Column(db.Date)
    gender = db.Column(db.String(20))
    blood_group = db.Column(db.String(5))
    # Needed to work out BMI from a weight reading. Kept on the profile
    # rather than each reading because it rarely changes for adults.
    height_cm = db.Column(db.Float)

    # Sensitive contact/medical fields — encrypted at rest
    address = db.Column(EncryptedString(500))
    emergency_contact = db.Column(EncryptedString(255))
    known_allergies = db.Column(EncryptedString(500))
    chronic_conditions = db.Column(EncryptedString(500))

    created_at = db.Column(db.DateTime, default=utcnow)

    appointments = db.relationship("Appointment", backref="patient", cascade="all, delete-orphan",
                                    foreign_keys="Appointment.patient_id")
    records = db.relationship("MedicalRecord", backref="patient", cascade="all, delete-orphan")
    vitals = db.relationship("VitalReading", backref="patient", cascade="all, delete-orphan")
    lab_reports = db.relationship("LabReport", backref="patient", cascade="all, delete-orphan")
