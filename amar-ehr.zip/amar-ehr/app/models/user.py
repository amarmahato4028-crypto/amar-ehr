import re
from datetime import timedelta
import bcrypt
from flask_login import UserMixin
from app.extensions import db
from app.utils.timeutils import utcnow


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="patient")  # patient|doctor|admin
    full_name = db.Column(db.String(120), nullable=False)
    # Stored normalised (digits and a leading +) so "+1 (555) 014-2" and
    # "+15550142" are the same account. Unique so it can identify a user at
    # sign-in; NULL is allowed and SQL permits many NULLs, so phone stays
    # optional.
    phone = db.Column(db.String(30), unique=True, nullable=True, index=True)

    is_active_account = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=utcnow)

    # --- 2FA ---
    totp_secret = db.Column(db.String(64))
    two_fa_enabled = db.Column(db.Boolean, default=False)

    # --- Brute-force lockout ---
    failed_login_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime, nullable=True)
    last_login_at = db.Column(db.DateTime, nullable=True)

    patient_profile = db.relationship("PatientProfile", backref="user", uselist=False, cascade="all, delete-orphan")
    doctor_profile = db.relationship("DoctorProfile", backref="user", uselist=False, cascade="all, delete-orphan")

    # Flask-Login expects a string id
    def get_id(self):
        return str(self.id)

    # ---------------------------------------------------------- identifiers
    @staticmethod
    def normalize_phone(raw):
        """Reduce a typed number to digits (keeping a leading +) so the same
        phone always matches regardless of spaces, dashes or brackets."""
        if not raw:
            return None
        cleaned = re.sub(r"[^\d+]", "", str(raw))
        cleaned = "+" + cleaned.replace("+", "") if cleaned.startswith("+") \
            else cleaned.replace("+", "")
        return cleaned or None

    @staticmethod
    def looks_like_email(identifier):
        return "@" in (identifier or "")

    @classmethod
    def find_by_login(cls, identifier):
        """Look a user up by email address *or* phone number — whichever
        they typed into the single sign-in box."""
        ident = (identifier or "").strip()
        if not ident:
            return None
        if cls.looks_like_email(ident):
            return cls.query.filter_by(email=ident.lower()).first()
        phone = cls.normalize_phone(ident)
        if not phone:
            return None
        return cls.query.filter_by(phone=phone).first()

    @property
    def is_active(self):
        return self.is_active_account

    def set_password(self, raw_password: str):
        self.password_hash = bcrypt.hashpw(raw_password.encode(), bcrypt.gensalt()).decode()

    def check_password(self, raw_password: str) -> bool:
        try:
            return bcrypt.checkpw(raw_password.encode(), self.password_hash.encode())
        except ValueError:
            return False

    def is_locked(self) -> bool:
        return bool(self.locked_until and self.locked_until > utcnow())

    def register_failed_login(self, max_attempts: int, lockout_minutes: int):
        self.failed_login_attempts = (self.failed_login_attempts or 0) + 1
        if self.failed_login_attempts >= max_attempts:
            self.locked_until = utcnow() + timedelta(minutes=lockout_minutes)

    def register_successful_login(self):
        self.failed_login_attempts = 0
        self.locked_until = None
        self.last_login_at = utcnow()

    def __repr__(self):
        return f"<User {self.email} ({self.role})>"
