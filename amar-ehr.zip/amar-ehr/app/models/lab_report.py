from app.utils.timeutils import utcnow
from app.extensions import db


class LabReport(db.Model):
    __tablename__ = "lab_reports"

    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient_profiles.id"), nullable=False)
    uploaded_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    title = db.Column(db.String(255), nullable=False)
    stored_filename = db.Column(db.String(255), nullable=False)  # AES/Fernet-encrypted blob on disk
    original_filename = db.Column(db.String(255), nullable=False)
    content_type = db.Column(db.String(100))
    file_size = db.Column(db.Integer)

    uploaded_at = db.Column(db.DateTime, default=utcnow)
