from app.utils.timeutils import utcnow
from app.extensions import db


class VitalReading(db.Model):
    __tablename__ = "vital_readings"

    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient_profiles.id"), nullable=False)
    recorded_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    systolic_bp = db.Column(db.Integer)
    diastolic_bp = db.Column(db.Integer)
    heart_rate = db.Column(db.Integer)
    blood_sugar = db.Column(db.Float)   # mg/dL
    temperature = db.Column(db.Float)   # Celsius
    spo2 = db.Column(db.Integer)        # % oxygen saturation
    weight_kg = db.Column(db.Float)

    risk_flags = db.Column(db.String(500))  # comma-separated rule-based flags, e.g. "HIGH_BP,HIGH_SUGAR"

    recorded_at = db.Column(db.DateTime, default=utcnow)
