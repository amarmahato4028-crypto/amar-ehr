from app.utils.timeutils import utcnow
from app.extensions import db
from app.security.encryption import EncryptedString


class Prescription(db.Model):
    __tablename__ = "prescriptions"

    id = db.Column(db.Integer, primary_key=True)
    record_id = db.Column(db.Integer, db.ForeignKey("medical_records.id"), nullable=False)

    medication = db.Column(EncryptedString(255), nullable=False)
    dosage = db.Column(EncryptedString(120))
    frequency = db.Column(EncryptedString(120))
    duration = db.Column(EncryptedString(60))
    instructions = db.Column(EncryptedString(500))

    pdf_filename = db.Column(db.String(255))  # generated ReportLab PDF, encrypted at rest
    created_at = db.Column(db.DateTime, default=utcnow)
