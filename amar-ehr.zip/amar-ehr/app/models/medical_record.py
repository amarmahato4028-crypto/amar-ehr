from app.utils.timeutils import utcnow
from app.extensions import db
from app.security.encryption import EncryptedString


class MedicalRecord(db.Model):
    __tablename__ = "medical_records"

    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient_profiles.id"), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey("doctor_profiles.id"), nullable=False)
    appointment_id = db.Column(db.Integer, db.ForeignKey("appointments.id"), nullable=True)

    # PHI fields encrypted individually at the column level (not just
    # "the whole DB") per the security spec.
    diagnosis = db.Column(EncryptedString(1000))
    notes = db.Column(EncryptedString(2000))

    record_type = db.Column(db.String(30), default="consultation")  # consultation|diagnosis|note
    created_at = db.Column(db.DateTime, default=utcnow)

    prescriptions = db.relationship("Prescription", backref="record", cascade="all, delete-orphan")

    def searchable_text(self):
        """Decrypted text used for in-app search/filter (never indexed in
        plaintext in the DB itself)."""
        return f"{self.diagnosis or ''} {self.notes or ''} {self.record_type}"
