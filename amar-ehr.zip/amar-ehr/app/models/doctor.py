from app.utils.timeutils import utcnow
from app.extensions import db


class DoctorProfile(db.Model):
    __tablename__ = "doctor_profiles"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, unique=True)

    specialization = db.Column(db.String(120), nullable=False, default="General Medicine")
    license_number = db.Column(db.String(60))
    years_experience = db.Column(db.Integer, default=0)
    bio = db.Column(db.Text)

    created_at = db.Column(db.DateTime, default=utcnow)

    appointments = db.relationship("Appointment", backref="doctor", cascade="all, delete-orphan",
                                    foreign_keys="Appointment.doctor_id")
    records_authored = db.relationship("MedicalRecord", backref="doctor")
