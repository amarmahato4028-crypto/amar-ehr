from flask import Blueprint, redirect, url_for
from flask_login import login_required, current_user

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    """There's no separate marketing page — signing in *is* the front door,
    and signing up lives on the same screen. Anyone already signed in goes
    straight to their own dashboard."""
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    return redirect(url_for("auth.login"))


@main_bp.route("/dashboard")
@login_required
def dashboard():
    if current_user.role == "patient":
        return redirect(url_for("patient.dashboard"))
    if current_user.role == "doctor":
        return redirect(url_for("doctor.dashboard"))
    if current_user.role == "admin":
        return redirect(url_for("admin.dashboard"))
    return redirect(url_for("auth.logout"))
