from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, IntegerField, FloatField, SubmitField
from wtforms.validators import DataRequired, Optional, Length


class DoctorProfileForm(FlaskForm):
    specialization = StringField("Specialization", validators=[DataRequired(), Length(max=120)])
    license_number = StringField("License Number", validators=[Optional(), Length(max=60)])
    years_experience = IntegerField("Years of Experience", validators=[Optional()])
    bio = TextAreaField("Bio", validators=[Optional(), Length(max=2000)])
    submit = SubmitField("Save Profile")


class MedicalRecordForm(FlaskForm):
    record_type = SelectField("Type", choices=[("consultation", "Consultation"), ("diagnosis", "Diagnosis"), ("note", "Note")])
    diagnosis = TextAreaField("Diagnosis", validators=[Optional(), Length(max=1000)])
    notes = TextAreaField("Clinical Notes", validators=[Optional(), Length(max=2000)])
    submit = SubmitField("Save Record")


class PrescriptionForm(FlaskForm):
    medication = StringField("Medication", validators=[DataRequired(), Length(max=255)])
    dosage = StringField("Dosage", validators=[Optional(), Length(max=120)])
    frequency = StringField("Frequency", validators=[Optional(), Length(max=120)])
    duration = StringField("Duration", validators=[Optional(), Length(max=60)])
    instructions = TextAreaField("Instructions", validators=[Optional(), Length(max=500)])
    submit = SubmitField("Generate Prescription")


class VitalsForm(FlaskForm):
    """Clinical shorthand is fine here — this form is doctor-facing."""
    systolic_bp = IntegerField("Systolic BP", validators=[Optional()], description="mmHg")
    diastolic_bp = IntegerField("Diastolic BP", validators=[Optional()], description="mmHg")
    heart_rate = IntegerField("Heart rate", validators=[Optional()], description="bpm")
    blood_sugar = FloatField("Blood glucose", validators=[Optional()], description="mg/dL")
    temperature = FloatField("Temperature", validators=[Optional()], description="°C")
    spo2 = IntegerField("SpO₂", validators=[Optional()], description="%")
    weight_kg = FloatField("Weight", validators=[Optional()], description="kg")
    submit = SubmitField("Record vitals")
