from collections import Counter
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, jsonify
from flask_login import login_required, current_user

from app.extensions import db
from app.models.patient import PatientProfile
from app.models.appointment import Appointment
from app.models.medical_record import MedicalRecord
from app.models.prescription import Prescription
from app.models.vitals import VitalReading
from app.security.decorators import role_required, log_action
from app.doctor.forms import DoctorProfileForm, MedicalRecordForm, PrescriptionForm, VitalsForm
from app.utils.anomaly import evaluate_vitals
from app.utils.timeutils import utcnow
from app.utils.forms import populate_model
from app.utils.pdf_generator import generate_prescription_pdf
from app.security.encryption import encrypt_bytes

doctor_bp = Blueprint("doctor", __name__)


def _own_profile_or_403():
    profile = current_user.doctor_profile
    if not profile:
        abort(403)
    return profile


def _assert_assigned(doctor_profile, patient_profile):
    """RBAC: a doctor may only act on patients they have an appointment
    history with (assigned patients) — enforced server-side on every call,
    not just hidden in the UI."""
    has_link = Appointment.query.filter_by(doctor_id=doctor_profile.id,
                                            patient_id=patient_profile.id).first()
    if not has_link:
        abort(403)


@doctor_bp.route("/dashboard")
@login_required
@role_required("doctor")
def dashboard():
    profile = _own_profile_or_403()
    upcoming = (Appointment.query.filter_by(doctor_id=profile.id)
                .filter(Appointment.scheduled_at >= utcnow())
                .order_by(Appointment.scheduled_at.asc()).limit(8).all())
    all_appts = Appointment.query.filter_by(doctor_id=profile.id).all()
    status_counts = Counter(a.status for a in all_appts)
    patient_count = db.session.query(Appointment.patient_id).filter_by(doctor_id=profile.id).distinct().count()
    log_action(current_user.id, "VIEW_DASHBOARD", "doctor_profile", profile.id)
    return render_template("doctor/dashboard.html", profile=profile, upcoming=upcoming,
                            status_counts=status_counts, patient_count=patient_count)


@doctor_bp.route("/appointments/stats-data")
@login_required
@role_required("doctor")
def appointment_stats_data():
    profile = _own_profile_or_403()
    all_appts = Appointment.query.filter_by(doctor_id=profile.id).all()
    counts = Counter(a.status for a in all_appts)
    return jsonify({"labels": list(counts.keys()), "values": list(counts.values())})


@doctor_bp.route("/appointments")
@login_required
@role_required("doctor")
def appointments():
    profile = _own_profile_or_403()
    status_filter = request.args.get("status", "").strip()
    query = Appointment.query.filter_by(doctor_id=profile.id)
    if status_filter in ("scheduled", "completed", "cancelled", "no_show"):
        query = query.filter_by(status=status_filter)
    appts = query.order_by(Appointment.scheduled_at.desc()).all()
    return render_template("doctor/appointments.html", appointments=appts,
                            status_filter=status_filter)


@doctor_bp.route("/appointments/<int:appt_id>/status", methods=["POST"])
@login_required
@role_required("doctor")
def update_appointment_status(appt_id):
    """Close out an appointment. Without this the status was stuck on
    'scheduled' forever and the dashboard breakdown chart never changed."""
    profile = _own_profile_or_403()
    appt = Appointment.query.get_or_404(appt_id)
    if appt.doctor_id != profile.id:
        abort(403)

    new_status = request.form.get("status", "")
    if new_status not in ("scheduled", "completed", "cancelled", "no_show"):
        flash("Invalid appointment status.", "danger")
        return redirect(url_for("doctor.appointments"))

    appt.status = new_status
    db.session.commit()
    log_action(current_user.id, "UPDATE_APPOINTMENT_STATUS", "appointment", appt.id,
               details=f"status={new_status}")
    flash(f"Appointment marked as {new_status.replace('_', ' ')}.", "success")
    return redirect(url_for("doctor.appointments"))


@doctor_bp.route("/profile", methods=["GET", "POST"])
@login_required
@role_required("doctor")
def profile():
    profile = _own_profile_or_403()
    form = DoctorProfileForm(obj=profile)
    if form.validate_on_submit():
        populate_model(form, profile)
        db.session.commit()
        log_action(current_user.id, "UPDATE_PROFILE", "doctor_profile", profile.id)
        flash("Profile updated.", "success")
        return redirect(url_for("doctor.profile"))
    return render_template("doctor/profile.html", form=form, profile=profile)


@doctor_bp.route("/patients")
@login_required
@role_required("doctor")
def patients():
    profile = _own_profile_or_403()
    patient_ids = [row[0] for row in db.session.query(Appointment.patient_id)
                   .filter_by(doctor_id=profile.id).distinct().all()]
    patients_list = PatientProfile.query.filter(PatientProfile.id.in_(patient_ids)).all()
    log_action(current_user.id, "VIEW_PATIENT_LIST", "doctor_profile", profile.id)
    return render_template("doctor/patients.html", patients=patients_list)


@doctor_bp.route("/patients/<int:patient_id>")
@login_required
@role_required("doctor")
def patient_detail(patient_id):
    profile = _own_profile_or_403()
    patient = PatientProfile.query.get_or_404(patient_id)
    _assert_assigned(profile, patient)
    records = MedicalRecord.query.filter_by(patient_id=patient.id).order_by(MedicalRecord.created_at.desc()).all()
    vitals = VitalReading.query.filter_by(patient_id=patient.id).order_by(VitalReading.recorded_at.desc()).limit(10).all()
    log_action(current_user.id, "VIEW_PATIENT_RECORD", "patient_profile", patient.id)
    return render_template("doctor/patient_detail.html", patient=patient, records=records, vitals=vitals)


@doctor_bp.route("/patients/<int:patient_id>/records/new", methods=["GET", "POST"])
@login_required
@role_required("doctor")
def add_record(patient_id):
    profile = _own_profile_or_403()
    patient = PatientProfile.query.get_or_404(patient_id)
    _assert_assigned(profile, patient)
    form = MedicalRecordForm()
    if form.validate_on_submit():
        record = MedicalRecord(patient_id=patient.id, doctor_id=profile.id)
        populate_model(form, record)
        db.session.add(record)
        db.session.commit()
        log_action(current_user.id, "CREATE_RECORD", "medical_record", record.id)
        flash("Medical record saved.", "success")
        return redirect(url_for("doctor.patient_detail", patient_id=patient.id))
    return render_template("doctor/add_record.html", form=form, patient=patient)


@doctor_bp.route("/patients/<int:patient_id>/vitals/new", methods=["GET", "POST"])
@login_required
@role_required("doctor")
def add_vitals(patient_id):
    profile = _own_profile_or_403()
    patient = PatientProfile.query.get_or_404(patient_id)
    _assert_assigned(profile, patient)
    form = VitalsForm()
    if form.validate_on_submit():
        v = VitalReading(patient_id=patient.id, recorded_by=current_user.id)
        populate_model(form, v)
        flags_csv, triggered = evaluate_vitals(v)
        v.risk_flags = flags_csv
        db.session.add(v)
        db.session.commit()
        log_action(current_user.id, "RECORD_VITALS", "vital_reading", v.id, details=flags_csv)
        if triggered:
            flash(f"Vitals recorded. Risk flags: {', '.join(t[2] for t in triggered)}", "warning")
        else:
            flash("Vitals recorded. Normal range.", "success")
        return redirect(url_for("doctor.patient_detail", patient_id=patient.id))
    return render_template("doctor/add_vitals.html", form=form, patient=patient)


@doctor_bp.route("/records/<int:record_id>/prescriptions/new", methods=["GET", "POST"])
@login_required
@role_required("doctor")
def add_prescription(record_id):
    profile = _own_profile_or_403()
    record = MedicalRecord.query.get_or_404(record_id)
    if record.doctor_id != profile.id:
        abort(403)
    form = PrescriptionForm()
    if form.validate_on_submit():
        rx = Prescription(record_id=record.id)
        populate_model(form, rx)
        db.session.add(rx)
        db.session.commit()

        pdf_bytes = generate_prescription_pdf(rx, record, record.patient.user, current_user, profile)
        stored_name = f"rx_{rx.id}.pdf.enc"
        from app.utils.uploads import upload_path
        import os
        os.makedirs(current_app_upload_dir(), exist_ok=True)
        with open(upload_path(stored_name), "wb") as f:
            f.write(encrypt_bytes(pdf_bytes))
        rx.pdf_filename = stored_name
        db.session.commit()

        log_action(current_user.id, "CREATE_PRESCRIPTION", "prescription", rx.id)
        flash("Prescription generated.", "success")
        return redirect(url_for("doctor.patient_detail", patient_id=record.patient_id))
    return render_template("doctor/add_prescription.html", form=form, record=record)


def current_app_upload_dir():
    from flask import current_app
    return current_app.config["UPLOAD_FOLDER"]


# Prescription/lab-report downloads are shared between doctor & patient
# roles and live in app/records/routes.py to keep the RBAC check in one
# place instead of duplicated per-blueprint.
