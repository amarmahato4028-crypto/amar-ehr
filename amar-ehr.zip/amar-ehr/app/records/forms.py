from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms import StringField, SubmitField, SelectField
from wtforms.validators import DataRequired, Length


class LabReportUploadForm(FlaskForm):
    title = StringField("Report Title", validators=[DataRequired(), Length(max=255)])
    file = FileField("File (PDF/JPG/PNG)", validators=[
        FileRequired(), FileAllowed(["pdf", "png", "jpg", "jpeg", "dcm"], "Unsupported file type.")])
    submit = SubmitField("Upload")
