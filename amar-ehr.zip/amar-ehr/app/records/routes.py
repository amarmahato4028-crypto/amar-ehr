import io
import os
from flask import (Blueprint, render_template, redirect, url_for, flash, abort,
                   send_file, request, current_app)
from flask_login import login_required, current_user

from app.extensions import db
from app.models.patient import PatientProfile
from app.models.prescription import Prescription
from app.models.lab_report import LabReport
from app.models.appointment import Appointment
from app.security.decorators import log_action
from app.security.encryption import encrypt_bytes, decrypt_bytes
from app.records.forms import LabReportUploadForm
from app.utils.uploads import allowed_file, safe_stored_name, upload_path

records_bp = Blueprint("records", __name__)


def _can_access_patient(patient: PatientProfile) -> bool:
    if current_user.role == "patient":
        return current_user.patient_profile and current_user.patient_profile.id == patient.id
    if current_user.role == "doctor":
        doc = current_user.doctor_profile
        return doc and Appointment.query.filter_by(doctor_id=doc.id, patient_id=patient.id).first() is not None
    if current_user.role == "admin":
        return True
    return False


def _can_access_prescription(rx: Prescription) -> bool:
    record = rx.record
    if current_user.role == "patient":
        return current_user.patient_profile and current_user.patient_profile.id == record.patient_id
    if current_user.role == "doctor":
        return current_user.doctor_profile and current_user.doctor_profile.id == record.doctor_id
    return current_user.role == "admin"


@records_bp.route("/prescriptions/<int:rx_id>/download")
@login_required
def download_prescription(rx_id):
    rx = Prescription.query.get_or_404(rx_id)
    if not _can_access_prescription(rx):
        abort(403)
    with open(upload_path(rx.pdf_filename), "rb") as f:
        data = decrypt_bytes(f.read())
    log_action(current_user.id, "DOWNLOAD_PRESCRIPTION", "prescription", rx.id)
    return send_file(io.BytesIO(data), mimetype="application/pdf", as_attachment=True,
                      download_name=f"prescription_{rx.id}.pdf")


@records_bp.route("/lab-reports/patient/<int:patient_id>")
@login_required
def lab_reports_for_patient(patient_id):
    patient = PatientProfile.query.get_or_404(patient_id)
    if not _can_access_patient(patient):
        abort(403)
    reports = LabReport.query.filter_by(patient_id=patient.id).order_by(LabReport.uploaded_at.desc()).all()
    log_action(current_user.id, "VIEW_LAB_REPORTS", "patient_profile", patient.id)
    return render_template("records/lab_reports.html", reports=reports, patient=patient)


@records_bp.route("/lab-reports/patient/<int:patient_id>/upload", methods=["GET", "POST"])
@login_required
def upload_lab_report(patient_id):
    patient = PatientProfile.query.get_or_404(patient_id)
    if not _can_access_patient(patient):
        abort(403)
    if current_user.role not in ("patient", "doctor", "admin"):
        abort(403)
    form = LabReportUploadForm()
    if form.validate_on_submit():
        f = form.file.data
        if not allowed_file(f.filename):
            flash("File type not allowed.", "danger")
            return render_template("records/upload_lab_report.html", form=form, patient=patient)

        raw = f.read()
        max_bytes = current_app.config["MAX_CONTENT_LENGTH"]
        if len(raw) > max_bytes:
            flash(f"File too large (max {max_bytes // (1024 * 1024)}MB).", "danger")
            return render_template("records/upload_lab_report.html", form=form, patient=patient)

        stored_name = safe_stored_name(f.filename)
        with open(upload_path(stored_name), "wb") as out:
            out.write(encrypt_bytes(raw))

        report = LabReport(patient_id=patient.id, uploaded_by=current_user.id, title=form.title.data,
                            stored_filename=stored_name, original_filename=f.filename,
                            content_type=f.mimetype, file_size=len(raw))
        db.session.add(report)
        db.session.commit()
        log_action(current_user.id, "UPLOAD_LAB_REPORT", "lab_report", report.id)
        flash("Lab report uploaded and encrypted at rest.", "success")
        return redirect(url_for("records.lab_reports_for_patient", patient_id=patient.id))
    return render_template("records/upload_lab_report.html", form=form, patient=patient)


@records_bp.route("/lab-reports/<int:report_id>/download")
@login_required
def download_lab_report(report_id):
    report = LabReport.query.get_or_404(report_id)
    patient = PatientProfile.query.get_or_404(report.patient_id)
    if not _can_access_patient(patient):
        abort(403)
    with open(upload_path(report.stored_filename), "rb") as f:
        data = decrypt_bytes(f.read())
    log_action(current_user.id, "DOWNLOAD_LAB_REPORT", "lab_report", report.id)
    return send_file(io.BytesIO(data), mimetype=report.content_type or "application/octet-stream",
                      as_attachment=True, download_name=report.original_filename)


@records_bp.route("/search")
@login_required
def search():
    """Search/filter medical records the current user is authorized to see."""
    from app.models.medical_record import MedicalRecord
    q = request.args.get("q", "").strip().lower()

    if current_user.role == "patient":
        if not current_user.patient_profile:
            abort(403)
        base = MedicalRecord.query.filter_by(patient_id=current_user.patient_profile.id)
    elif current_user.role == "doctor":
        if not current_user.doctor_profile:
            abort(403)
        base = MedicalRecord.query.filter_by(doctor_id=current_user.doctor_profile.id)
    elif current_user.role == "admin":
        base = MedicalRecord.query
    else:
        abort(403)

    results = base.order_by(MedicalRecord.created_at.desc()).all()
    if q:
        results = [r for r in results if q in r.searchable_text().lower()]
    log_action(current_user.id, "SEARCH_RECORDS", "medical_record", None, details=f"q={q}")
    return render_template("records/search_results.html", results=results, q=q)
