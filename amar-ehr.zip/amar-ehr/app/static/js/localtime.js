(function () {
  // Times are sent as UTC and rewritten here into the viewer's own
  // timezone, in a human format ("Sat, 15 Aug · 2:30 PM"). If JS is off,
  // the server-rendered "... UTC" text stays as a readable fallback.
  const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  function pad(n) { return String(n).padStart(2, '0'); }

  function relativeDay(d) {
    const today = new Date();
    const startOf = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    const diffDays = Math.round((startOf(d) - startOf(today)) / 86400000);
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    if (diffDays === -1) return 'Yesterday';
    return null;
  }

  document.querySelectorAll('time.js-localtime').forEach(function (el) {
    const iso = el.getAttribute('datetime');
    if (!iso) return;
    const d = new Date(iso);
    if (isNaN(d.getTime())) return;

    const hours24 = d.getHours();
    const hours12 = hours24 % 12 === 0 ? 12 : hours24 % 12;

    const tokens = {
      '%Y': d.getFullYear(),
      '%m': pad(d.getMonth() + 1),
      '%d': pad(d.getDate()),
      '%H': pad(hours24),
      '%I': hours12,
      '%M': pad(d.getMinutes()),
      '%S': pad(d.getSeconds()),
      '%p': hours24 < 12 ? 'AM' : 'PM',
      '%a': DAYS[d.getDay()],
      '%b': MONTHS[d.getMonth()],
    };

    let out = el.dataset.fmt || '%a, %d %b · %I:%M %p';
    Object.keys(tokens).forEach(function (k) {
      out = out.split(k).join(tokens[k]);
    });

    // "Today · 2:30 PM" reads better than a date for anything close by.
    const rel = relativeDay(d);
    if (rel && out.includes('·')) {
      out = rel + ' ·' + out.split('·').slice(1).join('·');
    }

    el.textContent = out;
    el.title = d.toLocaleString();
  });
})();
