(function () {
  const canvas = document.getElementById('statsChart');
  if (!canvas) return;

  fetch(canvas.dataset.url).then(r => r.json()).then(data => {
    new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels: data.labels,
        datasets: [{ data: data.values, backgroundColor: ['#0f766e', '#1d4ed8', '#b45309', '#64748b'] }],
      },
      options: { plugins: { legend: { position: 'bottom' } } },
    });
  });
})();
