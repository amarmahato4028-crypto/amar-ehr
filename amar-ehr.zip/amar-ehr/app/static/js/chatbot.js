(function () {
  const toggleBtn = document.getElementById('chatbot-toggle');
  const panel = document.getElementById('chatbot-panel');
  const messages = document.getElementById('chatbot-messages');
  const input = document.getElementById('chatbot-input');
  const sendBtn = document.getElementById('chatbot-send');
  const chips = document.getElementById('chatbot-chips');
  const csrfEl = document.querySelector('meta[name="csrf-token"]');
  const csrfToken = csrfEl ? csrfEl.getAttribute('content') : '';

  if (!toggleBtn) return;

  let greeted = false;

  toggleBtn.addEventListener('click', function () {
    const opening = panel.style.display !== 'block';
    panel.style.display = opening ? 'block' : 'none';
    if (opening && !greeted) {
      greeted = true;
      appendMessage(
        "Hi! Tell me how you're feeling and I'll share some general guidance. " +
        "For anything urgent, please contact a doctor or emergency services.",
        'bot');
    }
    if (opening && input) input.focus();
  });

  function appendMessage(text, who) {
    const row = document.createElement('div');
    row.className = 'mb-2 ' + (who === 'user' ? 'text-end' : 'text-start');
    const bubble = document.createElement('span');
    bubble.className = 'd-inline-block px-3 py-2 ' +
      (who === 'user' ? 'text-white' : 'border');
    bubble.style.cssText = 'border-radius:14px;max-width:88%;line-height:1.45;' +
      (who === 'user'
        ? 'background:linear-gradient(135deg,#0f766e,#14a89b);border-bottom-right-radius:4px;'
        : 'background:#f6f9fb;border-bottom-left-radius:4px;');
    bubble.textContent = text;
    row.appendChild(bubble);
    messages.appendChild(row);
    messages.scrollTop = messages.scrollHeight;
  }

  async function send(preset) {
    const text = (preset || input.value).trim();
    if (!text) return;
    appendMessage(text, 'user');
    input.value = '';

    const typing = document.createElement('div');
    typing.className = 'text-muted small mb-2';
    typing.textContent = 'Typing…';
    messages.appendChild(typing);
    messages.scrollTop = messages.scrollHeight;

    try {
      const resp = await fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrfToken },
        body: JSON.stringify({ message: text }),
      });
      const data = await resp.json();
      typing.remove();
      appendMessage(data.reply || data.error || 'Sorry, something went wrong.', 'bot');
    } catch (e) {
      typing.remove();
      appendMessage("I can't reach the assistant right now. Please try again in a moment.", 'bot');
    }
  }

  sendBtn.addEventListener('click', function () { send(); });
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter') send(); });

  if (chips) {
    chips.addEventListener('click', function (e) {
      const chip = e.target.closest('.chip');
      if (chip) send(chip.dataset.msg);
    });
  }
})();
