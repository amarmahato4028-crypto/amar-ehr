(function () {
  // --- tabs: sign in / create account -------------------------------
  const tabs = document.querySelectorAll('.auth-tab');
  const panels = {
    login: document.getElementById('tab-login'),
    register: document.getElementById('tab-register'),
  };

  function show(name) {
    tabs.forEach(t => t.classList.toggle('active', t.dataset.tab === name));
    Object.keys(panels).forEach(k => {
      if (panels[k]) panels[k].classList.toggle('show', k === name);
    });
  }

  tabs.forEach(t => t.addEventListener('click', () => show(t.dataset.tab)));

  // --- reveal the 2-step code box only when asked -------------------
  const toggle2fa = document.getElementById('toggle-2fa');
  const totpWrap = document.getElementById('totp-wrap');
  if (toggle2fa && totpWrap) {
    toggle2fa.addEventListener('click', function () {
      const hidden = totpWrap.hasAttribute('hidden');
      if (hidden) {
        totpWrap.removeAttribute('hidden');
        toggle2fa.textContent = "I don't have a code";
        const input = totpWrap.querySelector('input');
        if (input) input.focus();
      } else {
        totpWrap.setAttribute('hidden', '');
        toggle2fa.textContent = 'I have a 6-digit code';
      }
    });
  }

  // --- reveal the role picker only for doctors ----------------------
  const toggleRole = document.getElementById('toggle-role');
  const roleWrap = document.getElementById('role-wrap');
  if (toggleRole && roleWrap) {
    toggleRole.addEventListener('click', function () {
      const hidden = roleWrap.hasAttribute('hidden');
      if (hidden) {
        roleWrap.removeAttribute('hidden');
        toggleRole.textContent = "Actually, I'm a patient";
      } else {
        roleWrap.setAttribute('hidden', '');
        toggleRole.textContent = "I'm a doctor, not a patient";
        const select = roleWrap.querySelector('select');
        if (select) select.value = 'patient';
      }
    });
  }

  // --- demo credentials, for anyone evaluating the project ----------
  const fill = document.getElementById('fill-demo');
  if (fill) {
    fill.addEventListener('click', function () {
      const email = document.getElementById('login-email');
      const password = document.getElementById('login-password');
      if (email) email.value = 'amit.patel@example.com';
      if (password) password.value = 'PatientPass123';
      if (password) password.focus();
    });
  }
})();
