(function () {
  const canvas = document.getElementById('vitalsChart');
  if (!canvas) return;

  fetch(canvas.dataset.url).then(r => r.json()).then(data => {
    new Chart(canvas, {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [
          { label: 'Systolic BP', data: data.systolic, borderColor: '#0f766e', tension: 0.3 },
          { label: 'Diastolic BP', data: data.diastolic, borderColor: '#1d4ed8', tension: 0.3 },
          { label: 'Heart Rate', data: data.heart_rate, borderColor: '#b45309', tension: 0.3 },
        ],
      },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } } },
    });
  });
})();
