(function () {
  // Tell the server which timezone the picked wall-clock time is in, so it
  // can be converted to UTC for storage. getTimezoneOffset() returns
  // (UTC - local) in minutes: 240 for EDT, -330 for IST.
  const tzField = document.querySelector('input[name="tz_offset"]');
  if (tzField) tzField.value = new Date().getTimezoneOffset();

  // Stop users picking a time in the past (server re-validates this too).
  const input = document.getElementById('scheduled_at');
  if (input) {
    const now = new Date(Date.now() - new Date().getTimezoneOffset() * 60000);
    input.min = now.toISOString().slice(0, 16);
  }
})();
