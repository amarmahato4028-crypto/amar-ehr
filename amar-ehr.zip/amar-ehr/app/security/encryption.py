"""
Field-level and file-level encryption for Amar EHR.

- Field-level: an SQLAlchemy TypeDecorator (`EncryptedString`) that
  transparently encrypts/decrypts individual sensitive columns (diagnosis,
  clinical notes, contact info, etc.) using Fernet (AES-128-CBC + HMAC).
  This means even a raw DB dump does not expose PHI in plaintext.

- File-level: `encrypt_bytes` / `decrypt_bytes` wrap uploaded lab
  reports/scans with the same authenticated-encryption scheme before they
  ever touch disk.

Keys are loaded from environment variables (FIELD_ENCRYPTION_KEY /
FILE_ENCRYPTION_KEY) — never hardcoded, never committed to git. If they are
missing (e.g. first local run), a key is generated and persisted to
`instance/keys.env` purely for demo convenience; production deployments
should set real keys via the hosting platform's secret manager.
"""
import os
from cryptography.fernet import Fernet, MultiFernet, InvalidToken
from flask import current_app
from sqlalchemy import String
from sqlalchemy.types import TypeDecorator

_KEYS_FILE = os.path.join(os.path.dirname(__file__), "..", "..", "instance", "keys.env")


def _ensure_key(env_name):
    key = os.environ.get(env_name)
    if key:
        return key
    # Demo convenience only: persist a generated key so restarts don't
    # invalidate previously-encrypted data. Never do this in real prod.
    os.makedirs(os.path.dirname(_KEYS_FILE), exist_ok=True)
    existing = {}
    if os.path.exists(_KEYS_FILE):
        with open(_KEYS_FILE) as f:
            for line in f:
                if "=" in line:
                    k, v = line.strip().split("=", 1)
                    existing[k] = v
    if env_name in existing:
        os.environ[env_name] = existing[env_name]
        return existing[env_name]
    new_key = Fernet.generate_key().decode()
    existing[env_name] = new_key
    with open(_KEYS_FILE, "w") as f:
        for k, v in existing.items():
            f.write(f"{k}={v}\n")
    os.environ[env_name] = new_key
    return new_key


def get_field_fernet() -> MultiFernet:
    key = _ensure_key("FIELD_ENCRYPTION_KEY")
    return MultiFernet([Fernet(key.encode())])


def get_file_fernet() -> MultiFernet:
    key = _ensure_key("FILE_ENCRYPTION_KEY")
    return MultiFernet([Fernet(key.encode())])


class EncryptedString(TypeDecorator):
    """Transparent column-level encryption for sensitive text fields."""

    impl = String
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        f = get_field_fernet()
        return f.encrypt(str(value).encode()).decode()

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        f = get_field_fernet()
        try:
            return f.decrypt(value.encode()).decode()
        except InvalidToken:
            # Data written before encryption was enabled, or wrong key.
            return value


def encrypt_bytes(data: bytes) -> bytes:
    return get_file_fernet().encrypt(data)


def decrypt_bytes(token: bytes) -> bytes:
    return get_file_fernet().decrypt(token)
