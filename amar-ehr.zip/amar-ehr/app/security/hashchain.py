"""
Blockchain-style hash chain for tamper-evident audit logging.

Every AuditLog row stores `prev_hash` (the hash of the previous row) and
`entry_hash` = SHA256(prev_hash || row fields). Because each hash commits to
the one before it, altering or deleting any historical row breaks the chain
from that point forward — `verify_chain()` walks the whole table and reports
the first broken link, giving the admin dashboard a tamper-evidence check
with no external ledger required.
"""
import hashlib

GENESIS_HASH = "0" * 64


def compute_entry_hash(prev_hash: str, user_id, action: str, target_type: str,
                        target_id, timestamp_iso: str, details: str = "") -> str:
    payload = "|".join([
        prev_hash or GENESIS_HASH,
        str(user_id),
        action or "",
        target_type or "",
        str(target_id),
        timestamp_iso or "",
        details or "",
    ])
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def verify_chain(entries):
    """entries: iterable of AuditLog ordered by id ascending.
    Returns (is_valid: bool, first_broken_id: int | None).
    """
    prev = GENESIS_HASH
    for entry in entries:
        expected = compute_entry_hash(
            prev, entry.user_id, entry.action, entry.target_type,
            entry.target_id, entry.timestamp.isoformat(), entry.details or "",
        )
        if expected != entry.entry_hash or entry.prev_hash != prev:
            return False, entry.id
        prev = entry.entry_hash
    return True, None
