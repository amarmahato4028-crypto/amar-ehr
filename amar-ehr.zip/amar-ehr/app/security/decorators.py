"""RBAC + audit-trail decorators used across every blueprint."""
from functools import wraps
from flask import abort, request, current_app
from flask_login import current_user
from sqlalchemy.exc import IntegrityError

from app.extensions import db
from app.models.audit_log import AuditLog
from app.security.hashchain import compute_entry_hash, GENESIS_HASH
from app.utils.timeutils import utcnow


def role_required(*roles):
    """Restrict a view to one or more roles. Always enforced server-side —
    hiding a button in the template is never sufficient authorization."""
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(401)
            if current_user.role not in roles:
                log_action(current_user.id, "ACCESS_DENIED", request.endpoint or "", None,
                           details=f"role={current_user.role} required={roles}")
                abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return decorator


def log_action(user_id, action, target_type, target_id, details="", _attempts=5):
    """Append-only audit log write, chained to the previous entry with
    SHA-256 so any later tampering is detectable (see security/hashchain.py).

    Call this *after* the route has committed its own work — this function
    commits, so pending unrelated changes would be swept along.

    Concurrency: two workers can read the same tail entry and both try to
    chain onto it. The unique constraint on prev_hash rejects the loser,
    which then retries against the refreshed tail. Without this the chain
    would silently fork and verify_chain() would report tampering that
    never happened.
    """
    ip = request.remote_addr if request else None

    for attempt in range(_attempts):
        last = AuditLog.query.order_by(AuditLog.id.desc()).first()
        prev_hash = last.entry_hash if last else GENESIS_HASH
        now = utcnow()
        entry_hash = compute_entry_hash(prev_hash, user_id, action, target_type, target_id,
                                         now.isoformat(), details)
        entry = AuditLog(
            user_id=user_id,
            action=action,
            target_type=target_type,
            target_id=target_id,
            details=details,
            timestamp=now,
            prev_hash=prev_hash,
            entry_hash=entry_hash,
            ip_address=ip,
        )
        db.session.add(entry)
        try:
            db.session.commit()
            return entry
        except IntegrityError:
            # Another worker chained onto the same tail first; retry.
            db.session.rollback()
            if attempt == _attempts - 1:
                current_app.logger.error(
                    "Audit log write failed after %s attempts (action=%s)", _attempts, action)
                return None
    return None


def audit(action, target_type):
    """Decorator form of log_action for simple view functions."""
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            result = fn(*args, **kwargs)
            target_id = kwargs.get("id") or kwargs.get("patient_id") or kwargs.get("record_id")
            uid = current_user.id if current_user.is_authenticated else None
            log_action(uid, action, target_type, target_id)
            return result
        return wrapped
    return decorator
