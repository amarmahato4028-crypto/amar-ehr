"""APScheduler job that sends appointment reminders (email + optional SMS)
a configurable window before each appointment. Started from run.py so it
only runs in the main web process, not on every gunicorn worker fork."""
from datetime import timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from app.utils.timeutils import utcnow


def start_scheduler(app):
    scheduler = BackgroundScheduler(daemon=True)

    def check_and_send_reminders():
        with app.app_context():
            from app.models.appointment import Appointment
            from app.utils.notifications import send_appointment_email, send_sms_reminder, appointment_reminder_text

            window_start = utcnow()
            window_end = window_start + timedelta(hours=24)
            due = (Appointment.query.filter(Appointment.status == "scheduled")
                   .filter(Appointment.reminder_sent.is_(False))
                   .filter(Appointment.scheduled_at >= window_start)
                   .filter(Appointment.scheduled_at <= window_end).all())

            for appt in due:
                patient_user = appt.patient.user
                doctor_user = appt.doctor.user
                text = appointment_reminder_text(appt, patient_user.full_name, doctor_user.full_name)
                send_appointment_email(patient_user.email, "Amar EHR — Appointment Reminder", text)
                send_sms_reminder(patient_user.phone, text)
                appt.reminder_sent = True

            if due:
                from app.extensions import db
                db.session.commit()

    scheduler.add_job(check_and_send_reminders, "interval", minutes=30, id="appointment_reminders",
                       replace_existing=True)
    scheduler.start()
    return scheduler
