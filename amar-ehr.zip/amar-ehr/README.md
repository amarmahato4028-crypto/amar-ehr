# Amar EHR

A secure, role-based Electronic Health Record (EHR) system built with Flask.
Designed as a capstone/major project: patient, doctor, and admin portals,
encrypted medical records, prescription PDFs, QR health cards, two-factor
authentication, a tamper-evident audit trail, rule-based anomaly detection,
and a rule-based symptom-checker chatbot.

> ⚠️ Educational project. Not certified for real clinical or PHI use as-is —
> see [Security Notes](#security-notes) for what a production rollout would
> still need.

## Table of contents

- [Feature overview](#feature-overview)
- [Tech stack](#tech-stack)
- [Architecture](#architecture)
- [Local setup](#local-setup)
- [Demo accounts](#demo-accounts)
- [Running the tests](#running-the-tests)
- [Deploying live (Render)](#deploying-live-render)
- [Deploying live (Railway)](#deploying-live-railway)
- [Pushing to GitHub](#pushing-to-github)
- [Security notes](#security-notes)
- [Project structure](#project-structure)

## Feature overview

**Core**
- A single front door: `/` goes straight to one page that holds both signing in
  and creating an account, on two tabs. There's no separate marketing page or
  signup page to get lost in.
- Sign in with **either an email address or a mobile number** (one box accepts
  both; numbers are normalised so formatting doesn't matter)
- The sign-in form shows just two fields; the 2-step code box and the
  doctor/patient role picker stay collapsed until someone needs them
- Role-based access control: patient / doctor / admin, enforced server-side on every route (not just hidden UI)
- Patient profiles & medical history; doctor profiles & specializations
- Searchable doctor directory, filterable by specialization
- Appointment booking and cancellation (patient), status management —
  completed / cancelled / no-show — and filtering (doctor)
- Medical records: diagnosis, clinical notes, prescriptions
- Timezone-correct scheduling: times are entered and displayed in the
  viewer's local timezone but stored as UTC

**Data & documents**
- Prescription PDF generation (ReportLab)
- Lab report / scan file upload, encrypted at rest
- Encrypted (password-protected) PDF export of a patient's full record history
- Search & filter across medical records

**Engagement**
- Email appointment reminders (SMTP via Flask-Mail); optional SMS via Twilio
- Background scheduler (APScheduler) sends reminders ~24h before each appointment
- Dashboards with Chart.js: vitals trends (patient), appointment stats (doctor)

**Security & monitoring**
- TOTP two-factor authentication (pyotp) with QR provisioning, **enforced**
  for doctor/admin accounts (server-side gate, not optional)
- QR "health card" for quick patient identification
- Role-based, append-only audit trail: every access is logged (who / what / when),
  filterable by user and action type
- Field-level encryption (Fernet) on sensitive columns (diagnosis, notes, address, allergies, etc.)
- File-level encryption on uploaded lab reports and generated prescription PDFs
- SHA-256 hash-chained audit log (blockchain-style tamper evidence), with an
  admin-facing "Verify Chain Integrity" check
- bcrypt password hashing, account lockout after repeated failed logins,
  CSRF protection, rate limiting on login/API, secure session cookies, security headers + CSP

**Self-check**
- A patient-facing health check that grades blood pressure, heart rate, oxygen
  level, blood sugar, temperature and **BMI** as good / watch / needs attention,
  each with a visual band scale, a plain-language explanation and what to do next
- BMI is computed from the weight reading plus the height on your profile
- Readings can be checked without saving, or saved to build up the trend chart

**Intelligence layer**
- Rule-based vitals risk flagging (high/low BP, blood sugar, heart rate, SpO2, fever)
- Rule-based symptom-checker chatbot widget (no external API/key required)

## Tech stack

| Layer | Tool |
|---|---|
| Backend | Python 3.11, Flask |
| Database | SQLite (default/dev) or PostgreSQL (production) via SQLAlchemy |
| Frontend | Jinja2 + Bootstrap 5 + vanilla JS |
| Auth | Flask-Login + bcrypt |
| 2FA | pyotp (TOTP) + qrcode |
| Encryption | `cryptography` (Fernet) for fields and files |
| PDF | ReportLab (generate) + pypdf (password-protect) |
| Charts | Chart.js |
| Email | Flask-Mail (SMTP) |
| SMS | Twilio (optional) |
| Scheduler | APScheduler |
| Server | Gunicorn |

## Architecture

```
app/
  auth/        one combined sign-in / sign-up page, 2FA setup, lockout
  patient/     patient dashboard, profile, appointments, vitals, exports
  doctor/      doctor dashboard, patient list, records, prescriptions, vitals
  admin/       user management, audit trail, chain-integrity check
  records/     shared lab-report + prescription downloads, record search
  api/         JSON endpoints (chatbot)
  security/    encryption.py, hashchain.py, decorators.py (RBAC + audit log)
  utils/       pdf_generator, qr_utils, notifications, anomaly, chatbot,
               uploads, timeutils (UTC discipline), forms (safe populate)
  models/      SQLAlchemy models
  templates/   Jinja2 templates (Bootstrap 5)
  static/      CSS + JS (no inline scripts — CSP-clean)
run.py         app entrypoint + scheduler bootstrap
seed.py        demo data (1 admin, 2 doctors, 3 patients)
init_db.py     idempotent schema creation for deploy hooks
tests/         pytest suite (security, appointments, clinical logic)
```

Every sensitive column (diagnosis, notes, address, allergies, chronic
conditions, prescription details) is encrypted individually at the
SQLAlchemy column level via a custom `EncryptedString` type — a raw
database dump does not expose PHI. Uploaded files and generated
prescription PDFs are additionally encrypted before being written to disk.
The audit log is append-only (no update/delete route exists anywhere in the
codebase for it) and each entry is SHA-256-chained to the previous one, so
tampering with historical rows is mathematically detectable — see
`/admin/audit-trail/verify`.

## Local setup

```bash
git clone <your-repo-url> amar-ehr
cd amar-ehr

python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt

cp .env.example .env
# Generate real encryption keys and paste them into .env:
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
# (paste the two outputs into FIELD_ENCRYPTION_KEY and FILE_ENCRYPTION_KEY)

# Also set a real SECRET_KEY in .env:
python -c "import secrets; print(secrets.token_hex(32))"

python seed.py       # creates tables + demo admin/doctor/patient accounts
python run.py         # http://localhost:5000
```

If you skip setting `FIELD_ENCRYPTION_KEY` / `FILE_ENCRYPTION_KEY`, the app
auto-generates them into `instance/keys.env` on first run purely for local
convenience — **never rely on this for anything beyond local testing**; on a
host with an ephemeral filesystem those keys vanish on restart and
previously-encrypted data becomes unreadable.

## Demo accounts

Created by `python seed.py`:

| Role | Email | Password |
|---|---|---|
| Admin | admin@amarehr.com | AdminPass123 |
| Doctor | dr.sharma@amarehr.com | DoctorPass123 |
| Doctor | dr.khan@amarehr.com | DoctorPass123 |
| Patient | amit.patel@example.com | PatientPass123 |
| Patient | priya.nair@example.com | PatientPass123 |
| Patient | rahul.verma@example.com | PatientPass123 |

Doctor and admin accounts must complete 2FA setup on first login (you'll be
redirected automatically) — scan the QR with Google Authenticator, Authy, or
any TOTP app. **Change every demo password before deploying anywhere public.**

## Upgrading an existing database

Two later changes altered the schema: `users.phone` became unique (so it can
identify you at sign-in) and `patient_profiles.height_cm` was added for BMI.
`init_db.py` only creates missing tables — it won't alter existing ones. For a
local SQLite demo the simplest fix is to start fresh:

```bash
rm -f instance/amar_ehr.db && python seed.py
```

On a deployed Postgres database, add the columns with a migration
(`flask db migrate` / `flask db upgrade`) instead of dropping data.

## Running the tests

```bash
pip install -r requirements.txt   # includes pytest
pytest
```

The suite covers the parts most worth defending in a viva:

- **Security** (`tests/test_security.py`) — password hashing, account
  lockout, deactivated-account rejection, field-level encryption verified
  by reading raw ciphertext straight out of the DB, RBAC boundaries
  (patient↔patient, doctor↔unassigned patient, role↔area), 2FA
  enforcement, and audit-chain tamper detection (edit a row / delete a
  row → `verify_chain` pinpoints the break).
- **Appointments** (`tests/test_appointments.py`) — booking, past-date
  rejection, cross-tenant cancellation attempts, doctor status updates,
  and timezone conversion regression tests.
- **Clinical logic** (`tests/test_clinical.py`) — every anomaly rule and
  its boundary values, chatbot emergency precedence and disclaimers, QR
  generation, PDF password protection, and file-encryption round-trip.

## Timezone handling

Worth knowing, because it's the kind of thing that breaks quietly:
browsers submit `<input type="datetime-local">` as the user's *local wall
clock* with no offset attached. Amar EHR captures the offset in a hidden
field, converts to UTC on the way in, stores **every** datetime as naive
UTC, and converts back to local time in the browser on the way out
(`app/static/js/localtime.js` + the `|localdt` Jinja filter). Mixing
naive and aware datetimes in queries is what makes appointments
mysteriously disappear from "upcoming" lists — `app/utils/timeutils.py`
is the single source of truth so it can't drift.

## Deploying live (Render)

1. Push this repo to GitHub (see below).
2. On [render.com](https://render.com), choose **New → Blueprint**, point it
   at your GitHub repo — it will read `render.yaml` and provision a web
   service + a free Postgres database automatically.
3. In the service's **Environment** tab, set `FIELD_ENCRYPTION_KEY` and
   `FILE_ENCRYPTION_KEY` (generate with the command above — `render.yaml`
   intentionally leaves these for you to fill in rather than auto-generating
   invalid values).
4. Deploy. Render runs `python init_db.py` automatically before each start
   to keep the schema current.
5. Optionally, open a shell on the service (`Shell` tab) and run
   `python seed.py` once to load demo data.

## Deploying live (Railway)

1. Push this repo to GitHub.
2. On [railway.app](https://railway.app), **New Project → Deploy from GitHub repo**.
3. Add a **PostgreSQL** plugin; Railway injects `DATABASE_URL` automatically
   (Railway's Postgres URL uses `postgresql://`, which SQLAlchemy accepts directly).
4. In **Variables**, set `SECRET_KEY`, `FIELD_ENCRYPTION_KEY`,
   `FILE_ENCRYPTION_KEY`, `SESSION_COOKIE_SECURE=true`, and `FLASK_ENV=production`.
5. Set the start command to `python init_db.py && gunicorn run:app --workers 3 --bind 0.0.0.0:$PORT`.
6. Deploy, then optionally run `python seed.py` from Railway's shell for demo data.

## Pushing to GitHub

The project already is a git repository with a `main` branch, so you just
need to add the remote:

```bash
git remote add origin https://github.com/<your-username>/amar-ehr.git
git push -u origin main
```

**[DEPLOY.md](DEPLOY.md) walks through this step by step**, including
creating the repository, using an access token instead of a password,
and going live on Render.

`.gitignore` already excludes `.env`, the SQLite DB, `instance/` (which
holds auto-generated demo encryption keys), and the `venv/` folder, so
secrets won't be committed.

## Security notes

Implemented, matching the original spec:

- Individually encrypted sensitive fields (Fernet), not just whole-DB encryption
- Uploaded files encrypted at rest (Fernet/AES) before touching disk
- Encryption keys read from environment variables, never hardcoded
- bcrypt password hashing
- TOTP 2FA enforced server-side for doctor/admin roles
- Account lockout after `MAX_LOGIN_ATTEMPTS` failed logins (default 5, 15 min)
- HttpOnly, SameSite, and (in production) Secure session cookies
- Server-side RBAC on every route via `@role_required(...)`, plus
  per-resource ownership checks (a doctor can only act on patients they
  have an appointment with; a patient can only see their own data)
- Parameterized queries throughout (SQLAlchemy ORM — no raw string SQL)
- CSRF protection (Flask-WTF) on every form
- Rate limiting on login and the chatbot API
- File upload validation: extension allowlist + 10MB size cap
- Security headers + a CSP with no inline scripts (all JS lives in `static/js/`)
- Append-only, hash-chained audit log with an integrity-verification view

Still needed before any real deployment with real patient data:
- HTTPS/TLS termination (Render/Railway provide this automatically at the
  platform edge; `SESSION_COOKIE_SECURE=true` assumes it)
- A real secrets manager for `SECRET_KEY` / encryption keys instead of
  platform env vars
- Malware/content scanning on uploaded files (currently: extension + size only)
- Automated, separately-encrypted backups
- A formal risk assessment / compliance review (HIPAA or local equivalent)
  — this project demonstrates the patterns, not a compliance certification

## Project structure

See [Architecture](#architecture) above for the annotated tree.
