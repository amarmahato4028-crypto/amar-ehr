# Putting Amar EHR on GitHub and making it live

Two stages: get the code onto GitHub, then point a free host at it.
Budget about 20 minutes the first time.

---

## Stage 1 — Push to GitHub

The project is already a git repository with your commits on a `main`
branch, so you only need to create the remote and push.

### 1. Create an empty repository on GitHub

Go to <https://github.com/new> and set:

- **Repository name:** `amar-ehr`
- **Description:** *Secure role-based Electronic Health Record system built with Flask*
- **Public** (so an examiner can see it without being invited)
- **Do NOT tick** "Add a README", ".gitignore" or "Choose a license" —
  the project already has them, and ticking these creates a conflicting
  first commit.

Click **Create repository**.

### 2. Push from your computer

Unzip the project, open a terminal inside the `amar-ehr` folder, and run
the four lines below. Replace `<your-username>` with your GitHub username.

```bash
git remote add origin https://github.com/<your-username>/amar-ehr.git
git branch -M main
git push -u origin main
```

If git asks for a password, GitHub no longer accepts your account
password. Create a **personal access token** instead:

1. <https://github.com/settings/tokens> → *Generate new token (classic)*
2. Tick the **`repo`** scope, generate, and copy the token
3. Paste the token when git asks for a password

> Already ran `git init` yourself and hit
> `remote origin already exists`? Run `git remote set-url origin <url>`
> instead of `git remote add`.

### 3. Check what landed

Refresh the repository page. You should see the folders and the README
rendered underneath. Confirm these are **absent** — `.gitignore` keeps
them out, and their presence would mean secrets leaked:

- `.env`
- `instance/`
- `venv/`
- any `.db` file

---

## Stage 2 — Make it live on Render (free)

Render reads `render.yaml` from the repository and sets up both the web
service and a Postgres database automatically.

### 1. Create the service

1. Sign up at <https://render.com> with your GitHub account
2. **New → Blueprint**
3. Pick your `amar-ehr` repository and click **Apply**

Render now creates a web service plus a free Postgres database.

### 2. Add the two encryption keys

This step is required — the app will start without them, but it would
generate throwaway keys that vanish on the next restart, making saved
records permanently unreadable.

Generate two keys on your own machine:

```bash
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

In Render: your service → **Environment** → add

| Key | Value |
|---|---|
| `FIELD_ENCRYPTION_KEY` | the first generated key |
| `FILE_ENCRYPTION_KEY` | the second generated key |

`SECRET_KEY` and `DATABASE_URL` are filled in automatically by the
blueprint. Save — Render redeploys.

### 3. Load the demo data

Service → **Shell** tab:

```bash
python seed.py
```

That creates the admin, two doctors and three patients listed in the
README. Your site is live at `https://amar-ehr.onrender.com` (Render shows
the exact address at the top of the service page).

> **Free tier note:** the service sleeps after ~15 minutes of no traffic,
> so the first visit afterwards takes 30–50 seconds to wake. Open the link
> a minute *before* a demo or presentation so it's already awake.

---

## Before anyone else uses it

- **Change every demo password.** They're published in the README, so
  anyone can read them. Sign in as admin and change them, or edit
  `seed.py` before seeding.
- **Keep `SESSION_COOKIE_SECURE=true`** in production (the blueprint sets
  this). Render terminates HTTPS for you.
- **Never commit `.env`.** If you ever do, treat those keys as burned:
  generate new ones and update them on the host.

---

## Making the repository look good

Examiners look at the front page first. Two quick wins:

1. **About section** (gear icon, top right of the repo page) — add the
   description and topics like `flask`, `healthcare`, `python`,
   `encryption`, `capstone-project`.
2. **Add the live link** to the About section's *Website* field so it
   appears at the top of the page.

If you want screenshots in the README, take them from the running site
and put them in a `docs/` folder, then reference them:

```markdown
![Patient dashboard](docs/dashboard.png)
```

---

## If something breaks

| Symptom | Cause and fix |
|---|---|
| Build fails on `pip install` | Check Render's build log for the failing package. `runtime.txt` pins Python 3.11 — the versions in `requirements.txt` are tested against it. |
| Site loads but every page errors | Usually the database. Confirm `DATABASE_URL` exists under Environment and that the Postgres instance shows *available*. |
| "Internal Server Error" after a redeploy | Most often a missing `FIELD_ENCRYPTION_KEY` / `FILE_ENCRYPTION_KEY`. Check the Environment tab. |
| Old records became unreadable | The encryption keys changed. They must stay identical for the life of the data — restore the originals if you still have them. |
| Login always says "details don't match" | The database has no users yet. Run `python seed.py` in the Shell tab. |
